/**
 * PatientSearch — powerful backend-driven search for doctors and admins.
 *
 * Searches by: Patient ID, Client ID, animal name, breed, species, client name, phone.
 * Results show: Patient ID, animal name, species, breed, Client ID, client name, address, phone, status, last visit.
 * Clicking a result opens the patient profile.
 * Privacy is enforced by role — doctor sees only authorized records, admin sees all.
 */

import { useState, useMemo } from 'react';
import { Search, X, PawPrint, MapPin, Phone, ArrowUpRight, Loader2 } from 'lucide-react';
import { SPECIES_LIST } from '@/lib/demo-data';
import { db } from '@/lib/db';
import { demoPatients, demoClients } from '@/lib/demo-data';

interface SearchResult {
  patientId: string;
  name: string;
  species: string;
  customSpecies: string | null;
  breed: string | null;
  sex: string | null;
  clientId: string;
  clientName: string;
  city: string;
  state: string;
  phone: string;
  status: string;
  lastVisit: string;
}

interface PatientSearchProps {
  role: 'doctor' | 'admin';
  onSelectPatient: (patientId: string) => void;
}

export function PatientSearch({ role, onSelectPatient }: PatientSearchProps) {
  const [query, setQuery] = useState('');
  const [speciesFilter, setSpeciesFilter] = useState('');
  const [results, setResults] = useState<SearchResult[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const buildDemoResults = (): SearchResult[] => {
    return demoPatients.map((p) => {
      const client = demoClients.find((c) => c.clientId === p[6]);
      return {
        patientId: p[6] as string,
        name: p[0] as string,
        species: p[1] as string,
        customSpecies: null,
        breed: (p[2] as string).split(' · ')[0],
        sex: null,
        clientId: p[6] as string,
        clientName: p[4] as string,
        city: client?.city ?? '',
        state: '',
        phone: client?.phone ?? '',
        status: client?.status ?? 'Active',
        lastVisit: p[5] as string,
      };
    });
  };

  const performSearch = async () => {
    setLoading(true);
    setSearched(true);

    // Try backend search
    let backendResults: SearchResult[] | null = null;

    if (query.trim()) {
      backendResults = await db.searchPatients(query) as unknown as SearchResult[] | null;
    } else {
      const all = await db.getPatients();
      if (all) {
        backendResults = all.map((p) => ({
          patientId: p.patient_id,
          name: p.name,
          species: p.species,
          customSpecies: p.custom_species,
          breed: p.breed,
          sex: p.sex,
          clientId: p.client_id,
          clientName: '',
          city: '',
          state: '',
          phone: '',
          status: p.status,
          lastVisit: '',
        }));
      }
    }

    if (backendResults && backendResults.length > 0) {
      // Enrich with client data
      const clients = await db.getClients();
      if (clients) {
        backendResults = backendResults.map((r) => {
          const c = clients.find((cl) => cl.client_id === r.clientId);
          return c ? { ...r, clientName: c.full_name, city: c.city ?? '', state: c.state ?? '', phone: c.phone } : r;
        });
      }
      // Apply species filter
      if (speciesFilter) {
        backendResults = backendResults.filter((r) => r.species === speciesFilter);
      }
      setResults(backendResults);
    } else {
      // Fallback to demo data
      let demo = buildDemoResults();
      if (speciesFilter) {
        demo = demo.filter((r) => r.species === speciesFilter);
      }
      if (query.trim()) {
        const q = query.toLowerCase();
        demo = demo.filter((r) =>
          r.patientId.toLowerCase().includes(q) ||
          r.name.toLowerCase().includes(q) ||
          r.breed?.toLowerCase().includes(q) ||
          r.species.toLowerCase().includes(q) ||
          r.clientId.toLowerCase().includes(q) ||
          r.clientName.toLowerCase().includes(q) ||
          r.phone.includes(q),
        );
      }
      setResults(demo);
    }

    setLoading(false);
  };

  const filteredResults = useMemo(() => {
    if (!results) return [];
    if (!speciesFilter) return results;
    return results.filter((r) => r.species === speciesFilter);
  }, [results, speciesFilter]);

  return (
    <div className="patient-search-container">
      <div className="search-bar-row">
        <div className="searchbar large">
          <Search size={18} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && performSearch()}
            placeholder="Search by Patient ID, Client ID, animal name, breed, species, client name, or phone..."
          />
          {query && <button onClick={() => { setQuery(''); setResults(null); setSearched(false); }}><X size={15} /></button>}
        </div>
        <select className="species-filter" value={speciesFilter} onChange={(e) => setSpeciesFilter(e.target.value)}>
          <option value="">All Species</option>
          {SPECIES_LIST.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <button className="primary" onClick={performSearch} disabled={loading}>
          {loading ? <Loader2 size={16} className="spin" /> : <Search size={16} />}
          Search
        </button>
      </div>

      <div className="search-meta">
        <small>
          {role === 'doctor'
            ? 'You will only see patients you are authorized to access.'
            : 'Admin access: all patient records are visible.'}
        </small>
      </div>

      {searched && (
        <div className="search-results">
          {loading ? (
            <div className="search-loading"><Loader2 size={24} className="spin" /><p>Searching...</p></div>
          ) : filteredResults.length === 0 ? (
            <div className="empty-state"><PawPrint size={36} /><h3>No results found</h3><p>Try a different search term or filter.</p></div>
          ) : (
            <>
              <div className="results-count">{filteredResults.length} {filteredResults.length === 1 ? 'result' : 'results'} found</div>
              {filteredResults.map((r) => (
                <button
                  key={r.patientId}
                  className="search-result-card"
                  onClick={() => onSelectPatient(r.patientId)}
                >
                  <div className="result-pet-icon"><PawPrint size={18} /></div>
                  <div className="result-main">
                    <div className="result-primary">
                      <strong>{r.name}</strong>
                      <em className={`tag ${r.species.toLowerCase()}`}>{r.species === 'Other' ? r.customSpecies ?? 'Other' : r.species}</em>
                      {r.breed && <span className="muted">{r.breed}</span>}
                    </div>
                    <div className="result-ids">
                      <span className="pid">{r.patientId}</span>
                      <span className="dot">·</span>
                      <span className="cid">{r.clientId}</span>
                    </div>
                    <div className="result-secondary">
                      <span>{r.clientName}</span>
                      <small><MapPin size={11} /> {r.city}{r.state ? `, ${r.state}` : ''}</small>
                      <small><Phone size={11} /> {r.phone}</small>
                    </div>
                  </div>
                  <div className="result-actions">
                    <span className={`status ${r.status.toLowerCase()}`}>{r.status.toUpperCase()}</span>
                    <small>Last: {r.lastVisit}</small>
                    <span className="open-link">Open Profile <ArrowUpRight size={12} /></span>
                  </div>
                </button>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  );
}
