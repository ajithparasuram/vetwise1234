import { useCallback, useEffect, useMemo, useState, useRef } from 'react';
import {
  Activity, Bell, CalendarDays, ChevronDown, CircleDollarSign, ClipboardList, CreditCard,
  FileText, LayoutDashboard, Menu, PawPrint, Plus, Search, Settings, ShieldCheck,
  Stethoscope, UserRound, Users, X, LogOut, ArrowUpRight, Clock3, MoreHorizontal, Check,
  Shield, Ban, Download, AlertTriangle, DollarSign, Loader2, MapPin, Heart,
  ShoppingCart, Package, Pill, Star, Cloud, UserCheck, GraduationCap,
} from 'lucide-react';
import {
  type Role, type AuthUser,
  signUp as authSignUp, signInWithPassword, sendOtp as authSendOtp, verifyOtp as authVerifyOtp,
  signOut as authSignOut, getCurrentUser, onAuthStateChange,
} from '@/lib/auth';
import {
  fetchClients, fetchPatients, fetchAppointments, fetchClinicalRecords,
  fetchPrescriptions, fetchPayments, fetchSubscriptions, fetchSubscriptionPlans,
  fetchDoctors, fetchPendingDoctors, fetchClientsByUser, fetchPatientsByClient,
  approveDoctor as dbApproveDoctor, rejectDoctor as dbRejectDoctor,
  insertAppointment, insertPatient,
  fetchNotifications, markNotificationRead, markAllNotificationsRead,
} from '@/lib/queries';
import {
  BREED_SUGGESTIONS, SPECIES_LIST,
  demoClients, demoPatients, demoMyPets, demoClientLocations, demoPlans,
  demoPaidPayments, demoUpcomingPayments, demoLivePayments,
  demoAllPayments, demoAllSubs, demoPendingDoctors, demoActiveDoctors,
  demoAppointments, demoClinicalRecords, demoPrescriptions,
  demoNotifications, demoDoctorNotifications, demoAdminNotifications,
} from '@/lib/demo-data';
import { AddPetModal as AddPetModalNew } from '@/components/AddPetModal';
import { BreedingPanel } from '@/components/BreedingPanel';
import { GpsLocationPicker } from '@/components/GpsLocationPicker';
import { PatientSearch } from '@/components/PatientSearch';
import { PatientDetailPanel } from '@/components/PatientDetailPanel';
import {
  ShopHome, ShopCatalog, ProductDetail, Cart, Checkout,
  MyOrders, OrderDetail, DoctorShop,
  type CartItem,
} from '@/components/Shop';
import {
  AdminShopDashboard, AdminProducts, AdminOrders,
  AdminOrderDetail, AdminInventory, AddProductModal,
} from '@/components/AdminShop';
import { type ShopProduct } from '@/lib/shop-data';
import { CareStateMachine } from '@/components/CareStateMachine';
import { ClinicalContextBuilder } from '@/components/ClinicalContextBuilder';
import { AssignmentEngine } from '@/components/AssignmentEngine';
import { AuditTimeline } from '@/components/AuditTimeline';
import { OfflineSyncPanel } from '@/components/OfflineSyncPanel';
import { IdentityResolution } from '@/components/IdentityResolution';
import { PractitionerOnboarding } from '@/components/PractitionerOnboarding';
import {
  type AppointmentState, type CareState, type AuditEvent,
  type ClinicalContext, type AssignmentDecision,
  CARE_STATE_LABELS, CARE_STATE_COLORS,
} from '@/lib/orchestration';
import { supabase } from '@/lib/supabase';
import { offlineSync } from '@/lib/offline-sync';

type Page =
  | 'Dashboard' | 'Appointments' | 'Clients' | 'Patients' | 'Clinical Records'
  | 'Prescriptions' | 'Payments' | 'Follow-ups' | 'Notifications' | 'Schedule'
  | 'Settings' | 'My Pets' | 'Visits' | 'Medical Records' | 'Subscription'
  | 'Profile' | 'Doctor Approval' | 'Doctors' | 'Subscriptions' | 'Breeding' | 'Search'
  | 'Shop' | 'Shop Catalog' | 'Product Detail' | 'Cart' | 'Checkout'
  | 'My Orders' | 'Order Detail' | 'About'
  | 'Shop Dashboard' | 'Shop Products' | 'Shop Orders' | 'Shop Inventory'
  | 'Admin Order Detail' | 'Add Product'
  | 'Care Orchestration' | 'Clinical Context' | 'Audit Timeline' | 'Offline Sync'
  | 'Identity Integrity'
  | 'Practitioner Onboarding' | 'Onboarding Queue' | 'Onboarding Audit';

type Icon = typeof LayoutDashboard;

const adminNav: { label: Page; icon: Icon }[] = [
  { label: 'Dashboard', icon: LayoutDashboard },
  { label: 'Doctor Approval', icon: Shield },
  { label: 'Doctors', icon: Stethoscope },
  { label: 'Clients', icon: Users },
  { label: 'Patients', icon: PawPrint },
  { label: 'Search', icon: Search },
  { label: 'Breeding', icon: Heart },
  { label: 'Shop', icon: ShoppingCart },
  { label: 'Shop Orders', icon: Package },
  { label: 'Appointments', icon: CalendarDays },
  { label: 'Care Orchestration', icon: Activity },
  { label: 'Audit Timeline', icon: Clock3 },
  { label: 'Identity Integrity', icon: Shield },
  { label: 'Onboarding Queue', icon: UserCheck },
  { label: 'Onboarding Audit', icon: Clock3 },
  { label: 'Payments', icon: DollarSign },
  { label: 'Subscriptions', icon: ShieldCheck },
  { label: 'Notifications', icon: Bell },
  { label: 'Settings', icon: Settings },
];

const doctorNav: { label: Page; icon: Icon }[] = [
  { label: 'Dashboard', icon: LayoutDashboard }, { label: 'Appointments', icon: CalendarDays },
  { label: 'Clients', icon: Users }, { label: 'Patients', icon: PawPrint }, { label: 'Search', icon: Search }, { label: 'Breeding', icon: Heart },
  { label: 'Clinical Records', icon: FileText },
  { label: 'Prescriptions', icon: ClipboardList }, { label: 'Payments', icon: CircleDollarSign },
  { label: 'Follow-ups', icon: Clock3 }, { label: 'Care Orchestration', icon: Activity },
  { label: 'Clinical Context', icon: Stethoscope },
  { label: 'Identity Integrity', icon: Shield },
  { label: 'Practitioner Onboarding', icon: GraduationCap },
  { label: 'Offline Sync', icon: Cloud },
  { label: 'Shop', icon: ShoppingCart },
  { label: 'Notifications', icon: Bell }, { label: 'Schedule', icon: CalendarDays },
  { label: 'Settings', icon: Settings },
];

const clientNav: { label: Page; icon: Icon }[] = [
  { label: 'Dashboard', icon: LayoutDashboard }, { label: 'My Pets', icon: PawPrint }, { label: 'Visits', icon: CalendarDays },
  { label: 'Medical Records', icon: FileText }, { label: 'Prescriptions', icon: ClipboardList }, { label: 'Breeding', icon: Heart },
  { label: 'Shop', icon: ShoppingCart }, { label: 'My Orders', icon: Package },
  { label: 'Payments', icon: CreditCard },
  { label: 'Subscription', icon: ShieldCheck }, { label: 'Profile', icon: UserRound },
];

const frontdeskNav: { label: Page; icon: Icon }[] = [
  { label: 'Dashboard', icon: LayoutDashboard }, { label: 'Clients', icon: Users },
  { label: 'Patients', icon: PawPrint }, { label: 'Appointments', icon: CalendarDays },
  { label: 'Settings', icon: Settings },
];

const clients = demoClients;
const patients = demoPatients;
const allAppointments = demoAppointments;
const clinicalRecords = demoClinicalRecords;
const prescriptions = demoPrescriptions;
const allPayments = demoAllPayments;
const allSubs = demoAllSubs;
const plans = demoPlans;
const pendingDoctors = demoPendingDoctors;
const activeDoctors = demoActiveDoctors;
const paidPayments = demoPaidPayments;
const upcomingPayments = demoUpcomingPayments;
const livePayments = demoLivePayments;
const breeds = BREED_SUGGESTIONS;
const clientLocations = demoClientLocations;

function App() {
  const [authUser, setAuthUser] = useState<AuthUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [demoMode, setDemoMode] = useState(false);
  const demoModeRef = useRef(false);
  const [role, setRole] = useState<Role>('client');
  const [page, setPage] = useState<Page>('Dashboard');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [selectedClient, setSelectedClient] = useState(0);
  const [modal, setModal] = useState<string | null>(null);
  const [paymentTab, setPaymentTab] = useState<'all' | 'paid' | 'upcoming' | 'live'>('all');
  const [myPets, setMyPets] = useState<any[]>([]);
  const [profile, setProfile] = useState({ name: '', phone: '', email: '', address: '' });
  const [pendingDocs, setPendingDocs] = useState<any[]>([]);
  const [activeDocs, setActiveDocs] = useState<any[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [shopProduct, setShopProduct] = useState<ShopProduct | null>(null);
  const [shopOrderId, setShopOrderId] = useState<string | null>(null);
  const [adminOrderId, setAdminOrderId] = useState<string | null>(null);
  const [shopPet, setShopPet] = useState<string | null>(null);

  useEffect(() => {
    getCurrentUser().then((user) => {
      setAuthUser(user);
      if (user) { setRole(user.role); setPage(user.role === 'client' ? 'Dashboard' : user.role === 'admin' ? 'Dashboard' : 'Clients'); }
      setAuthLoading(false);
    });
    const unsub = onAuthStateChange((user) => {
      if (demoModeRef.current) return;
      setAuthUser(user);
      if (user) { setRole(user.role); setPage(user.role === 'client' ? 'Dashboard' : user.role === 'admin' ? 'Dashboard' : 'Clients'); }
      else { setRole('client'); }
      setAuthLoading(false);
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (!authUser) return;
    if (demoMode) {
      if (authUser.role === 'admin') { setPendingDocs(pendingDoctors); setActiveDocs(activeDoctors); }
      if (authUser.role === 'client') { setMyPets(demoMyPets); setProfile({ name: authUser.fullName, phone: authUser.phone, email: authUser.email, address: '12 MG Road, Bandra West, Mumbai, Maharashtra — 400050' }); }
      return;
    }
    if (authUser.role === 'admin') {
      fetchPendingDoctors().then(({ data }) => { if (data) setPendingDocs(data as any[]); });
      fetchDoctors().then(({ data }) => { if (data) setActiveDocs(data as any[]); });
    }
    if (authUser.role === 'client') {
      fetchClientsByUser(authUser.id).then(({ data }) => {
        if (data && data.length > 0) {
          const clientId = data[0].client_id;
          fetchPatientsByClient(clientId).then(({ data: pets }) => { if (pets) setMyPets(pets as any[]); });
        }
      });
      setProfile({ name: authUser.fullName, phone: authUser.phone, email: authUser.email, address: '' });
    }
  }, [authUser, demoMode]);

  const nav = role === 'admin' ? adminNav : role === 'doctor' ? doctorNav : role === 'client' ? clientNav : frontdeskNav;
  const filteredClients = useMemo(() => clients.filter((c) => `${c.name ?? ''} ${c.city ?? ''} ${c.pets ?? ''}`.toLowerCase().includes(query.toLowerCase())), [query]);

  const handleSignIn = useCallback((nextRole: Role, user?: AuthUser) => {
    if (user) { setAuthUser(user); setRole(user.role); setDemoMode(false); demoModeRef.current = false; }
    else {
      const demoUser: AuthUser = {
        id: `demo_${nextRole}`,
        email: `demo-${nextRole}@vetwise.app`,
        role: nextRole,
        fullName: nextRole === 'admin' ? 'Admin User' : nextRole === 'doctor' ? 'Dr. Anita Rao' : nextRole === 'frontdesk' ? 'Front Desk' : 'Priya Sharma',
        phone: '+91 9876543210',
        approvalStatus: 'approved',
        hospitalId: null,
      };
      setAuthUser(demoUser);
      setRole(nextRole);
      setDemoMode(true);
      demoModeRef.current = true;
    }
    setAuthLoading(false);
    setPage(nextRole === 'client' ? 'Dashboard' : nextRole === 'admin' ? 'Dashboard' : 'Clients');
  }, []);

  const handleSignOut = useCallback(() => { authSignOut(); setAuthUser(null); setRole('client'); setDemoMode(false); demoModeRef.current = false; }, []);

  if (authLoading) return <div className="login-screen"><div className="login-panel"><div className="login-box"><Loader2 size={24} className="spin" /></div></div></div>;
  if (!authUser) return <Login onSignIn={handleSignIn} />;

  const navigate = (next: Page) => { setPage(next); setMobileOpen(false); setQuery(''); };
  const roleInitial = role === 'client' ? (authUser.fullName?.[0] ?? 'C') : role === 'doctor' ? 'D' : role === 'admin' ? 'A' : 'F';
  const roleLabel = role === 'client' ? (authUser.fullName || 'Client') : role === 'doctor' ? 'Veterinarian' : role === 'admin' ? 'Administrator' : 'Front Desk';

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
        <div className="brand"><div className="brand-mark"><Stethoscope size={18} /></div><span>VetWise</span></div>
        <div className="portal-label">{role === 'doctor' ? 'DOCTOR PORTAL' : role === 'client' ? 'CLIENT PORTAL' : role === 'admin' ? 'ADMIN PORTAL' : 'FRONT DESK PORTAL'}</div>
        <nav>
          {nav.map(({ label, icon: NavIcon }) => (
            <button key={label} className={page === label ? 'nav-item active' : 'nav-item'} onClick={() => navigate(label)}>
              <NavIcon size={17} /><span>{label}</span>
              {label === 'Doctor Approval' && pendingDocs.length > 0 && <b className="nav-badge">{pendingDocs.length}</b>}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="user-mini"><div className="avatar small">{roleInitial}</div><span>{roleLabel}</span></div>
          <button className="signout" onClick={handleSignOut}><LogOut size={15} /> Sign out</button>
        </div>
      </aside>
      {mobileOpen && <button className="scrim" onClick={() => setMobileOpen(false)} aria-label="Close navigation" />}
      <main className="main-area">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMobileOpen(true)}><Menu size={20} /></button>
          <span className="date">{new Date().toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })}</span>
          <div className="top-actions">
            <button className="icon-btn" onClick={() => navigate('Notifications')}><Bell size={18} /><b>1</b></button>
            <button className="profile-btn" onClick={() => navigate(role === 'client' ? 'Profile' : 'Settings')}>
              <span>{roleInitial}</span><ChevronDown size={14} />
            </button>
          </div>
        </header>
        <div className="page-wrap">
          <div className="page-heading">
            <div><h1>{page}</h1><p>{subtitle(page, role)}</p></div>
            <div className="heading-actions">
              {role === 'client' && page === 'My Pets' && <button className="primary" onClick={() => setModal('Add Pet')}><Plus size={16} /> Add a pet</button>}
              {role === 'client' && page === 'Visits' && <button className="primary" onClick={() => setModal('Book a Visit')}><Plus size={16} /> Book a visit</button>}
              {role === 'doctor' && ['Clients', 'Patients', 'Appointments', 'Prescriptions'].includes(page) && (
                <button className="primary" onClick={() => setModal(`Add ${page === 'Appointments' ? 'Appointment' : page.slice(0, -1)}`)}>
                  <Plus size={16} /> Add {page === 'Appointments' ? 'Appointment' : page.slice(0, -1)}
                </button>
              )}
              {role === 'admin' && page === 'Shop Products' && <button className="primary" onClick={() => setModal('Add Product')}><Plus size={16} /> Add Product</button>}
              {role === 'client' && page === 'Shop Catalog' && cart.length > 0 && <button className="primary" onClick={() => navigate('Cart')}><ShoppingCart size={16} /> Cart ({cart.length})</button>}
              {role === 'client' && page === 'Shop' && <button className="primary" onClick={() => navigate('Shop Catalog')}><ShoppingCart size={16} /> Shop Now</button>}
            </div>
          </div>
          {renderPage(page, role, {
            query, setQuery, filteredClients, selectedClient, setSelectedClient,
            navigate, setModal, modal, paymentTab, setPaymentTab, myPets, setMyPets,
            profile, setProfile, pendingDocs, setPendingDocs, activeDocs, setActiveDocs,
            cart, setCart, shopProduct, setShopProduct, shopOrderId, setShopOrderId,
            adminOrderId, setAdminOrderId, shopPet, setShopPet,
            authUserId: authUser.id, demoMode,
          })}
        </div>
      </main>
      {modal && <ModalRouter modal={modal} setModal={setModal} role={role} myPets={myPets} setMyPets={setMyPets} />}
    </div>
  );
}

function subtitle(page: Page, role: Role) {
  const map: Partial<Record<Page, string>> = {
    Dashboard: role === 'client' ? 'Welcome back, Priya' : role === 'admin' ? 'Practice overview and system health' : 'Your practice at a glance',
    Clients: '5 registered clients', Patients: '8 patients across 5 clients',
    Payments: role === 'client' ? 'Your payments — paid, upcoming, and live' : 'Payment records for your services',
    'Follow-ups': 'Track patients requiring follow-up visits', Appointments: 'Manage upcoming appointments',
    'Clinical Records': 'Patient history and consultation notes', Prescriptions: role === 'client' ? 'Medicines prescribed to your pets (read-only)' : 'Manage medicines and digital prescriptions',
    Notifications: 'Stay updated with your practice', Schedule: 'Your working calendar',
    'My Pets': 'Your registered pets', Visits: 'Your upcoming and past visits',
    'Medical Records': 'Health history for your pets', Subscription: 'Your VetWise subscription plan',
    Profile: 'Manage your account and service locations', 'Doctor Approval': 'Review and approve pending doctor applications',
    Doctors: 'Active veterinarian accounts', Subscriptions: 'Subscription plans and renewals',
    Settings: 'System configuration',
    Search: role === 'doctor' ? 'Search patients by breed, species, ID, or owner' : 'Search all patients and clients',
    Breeding: role === 'client' ? 'Breeding records for your animals' : role === 'doctor' ? 'Search and view breeding animals' : 'All breeding records across clients',
    Shop: role === 'admin' ? 'Shop dashboard and management' : role === 'doctor' ? 'Browse veterinary products' : 'Veterinary medicines, food, supplements and healthcare products',
    'Shop Catalog': 'Browse products for all animals',
    'Product Detail': 'Product information and pricing',
    Cart: 'Your shopping cart',
    Checkout: 'Complete your order',
    'My Orders': 'Your shop order history',
    'Order Detail': 'Order details and tracking',
    'Shop Dashboard': 'Shop overview and metrics',
    'Shop Products': 'Manage product catalog',
    'Shop Orders': 'Manage customer orders',
    'Shop Inventory': 'Stock levels and inventory',
    'Admin Order Detail': 'Order details and fulfilment',
    'Care Orchestration': 'Veterinary care workflow with controlled state machine and doctor assignment',
    'Clinical Context': 'Assembled clinical context for patient care',
    'Audit Timeline': 'Event and audit trail for care workflows',
    'Offline Sync': 'Offline clinical data synchronization status',
    'Identity Integrity': 'Animal identity resolution and clinical history reconciliation',
    'Practitioner Onboarding': 'Doctor registration, KYC verification, and agreement signing',
    'Onboarding Queue': 'Pending practitioner verification and KYC review queue',
    'Onboarding Audit': 'Practitioner onboarding audit trail and state transitions',
  };
  return map[page] ?? 'Manage your VetWise account';
}

// ─── Demo data for orchestration features ───────────────────────
const demoAppointmentStates: AppointmentState[] = allAppointments.map((a, i) => ({
  appointmentId: a.appointmentId ?? `appt_${i}`,
  patientId: a.patientId ?? '',
  clientId: a.clientId ?? '',
  currentState: (a.status === 'Confirmed' ? 'DOCTOR_ASSIGNED' : 'PENDING_ADMIN_REVIEW') as CareState,
  reason: a.reason ?? '',
  appointmentType: (a.reason ?? '').includes('Vaccination') ? 'Vaccination' : 'Home Visit',
  preferredDate: '28 Sept 2026',
  preferredTime: a.time ?? '',
  location: a.visitLocation ?? null,
  assignedDoctorId: a.doctor ?? null,
  serviceabilityResult: null,
  createdAt: '28 Sept 2026',
  updatedAt: '28 Sept 2026',
}));

const demoAuditEvents: AuditEvent[] = [
  { eventId: 'evt_1', eventType: 'AppointmentRequested', entityId: 'demo_a1', entityType: 'appointment', actorId: 'priya@demo.com', actorRole: 'client', timestamp: '2026-09-28T08:30:00', previousState: null, resultingState: 'REQUESTED', metadata: { reason: 'Vaccination' }, correlationId: 'corr_1', source: 'server' },
  { eventId: 'evt_2', eventType: 'ServiceabilityChecked', entityId: 'demo_a1', entityType: 'appointment', actorId: 'system', actorRole: 'admin', timestamp: '2026-09-28T08:31:00', previousState: 'REQUESTED', resultingState: 'SERVICEABILITY_CHECK', metadata: { serviceable: true, area: 'Mumbai' }, correlationId: 'corr_1', source: 'server' },
  { eventId: 'evt_3', eventType: 'AdminApprovalGranted', entityId: 'demo_a1', entityType: 'appointment', actorId: 'admin@vetwise.com', actorRole: 'admin', timestamp: '2026-09-28T08:45:00', previousState: 'PENDING_ADMIN_REVIEW', resultingState: 'AUTHORIZED', metadata: { approvedBy: 'Admin' }, correlationId: 'corr_1', source: 'server' },
  { eventId: 'evt_4', eventType: 'DoctorAssigned', entityId: 'demo_a1', entityType: 'appointment', actorId: 'admin@vetwise.com', actorRole: 'admin', timestamp: '2026-09-28T09:00:00', previousState: 'ASSIGNMENT_PENDING', resultingState: 'DOCTOR_ASSIGNED', metadata: { doctorId: 'demo_ad1', doctorName: 'Dr. Anita Rao' }, correlationId: 'corr_1', source: 'server' },
  { eventId: 'evt_5', eventType: 'DoctorAccepted', entityId: 'demo_a1', entityType: 'appointment', actorId: 'demo_ad1', actorRole: 'doctor', timestamp: '2026-09-28T09:15:00', previousState: 'DOCTOR_ASSIGNED', resultingState: 'DOCTOR_ACCEPTED', metadata: null, correlationId: 'corr_1', source: 'server' },
];

const demoClinicalContext: ClinicalContext = {
  patientId: 'VW-CL-000001-P01',
  animal: {
    patientId: 'VW-CL-000001-P01', name: 'Bruno', species: 'Dog', breed: 'Labrador Retriever',
    sex: 'Male', dateOfBirth: '2023-07-15', age: '3y 2m', weight: '28.5 kg',
    color: 'Golden', markings: 'White patch on chest', microchipNumber: '985112003456789',
    allergies: 'None known', existingConditions: 'None', medicalHistory: 'Routine vaccinations up to date',
    vaccinationInfo: 'Rabies (Jan 2026), DHPP (Jan 2026)', medications: 'Multivitamin supplement',
    specialRequirements: 'Sensitive stomach — avoid dairy', breedingEligible: true,
    status: 'Active', registrationDate: '18 Mar 2025', lastVisit: '15 Sept 2026',
  },
  owner: {
    clientId: 'VW-CL-000001', name: 'Priya Sharma', phone: '+91 9876543210',
    email: 'priya@demo.com', address: '12 MG Road, Bandra West, Mumbai, Maharashtra — 400050',
    city: 'Mumbai', state: 'Maharashtra', pincode: '400050', status: 'Active',
  },
  currentAppointment: demoAppointmentStates[0],
  entries: [
    { type: 'record', date: '2026-09-15', title: 'Vaccination Visit', detail: 'Rabies + DHPP booster administered. No adverse reactions observed. Annual check-up in 1 year.', source: 'recorded', sourceLabel: 'Dr. Anita Rao' },
    { type: 'prescription', date: '2026-09-15', title: 'Multivitamin Supplement', detail: '1 tablet daily — ongoing', source: 'recorded', sourceLabel: 'Dr. Anita Rao' },
    { type: 'vaccination', date: '2026-01-15', title: 'Rabies Vaccination', detail: 'Rabies vaccine administered, valid 1 year', source: 'recorded', sourceLabel: 'Dr. Anita Rao' },
    { type: 'vaccination', date: '2026-01-15', title: 'DHPP Vaccination', detail: 'DHPP combination vaccine administered', source: 'recorded', sourceLabel: 'Dr. Anita Rao' },
    { type: 'weight', date: '2026-09-15', title: 'Weight Recorded', detail: '28.5 kg', source: 'recorded', sourceLabel: 'Clinical Record' },
  ],
  knownConditions: [],
  recentWeight: '28.5 kg',
  lastVaccination: 'Rabies (Jan 2026)',
  assembledAt: new Date().toISOString(),
};

const demoAssignmentDecision: AssignmentDecision = {
  appointmentId: 'demo_a1',
  selectedVeterinarian: {
    doctorId: 'demo_ad1', name: 'Dr. Anita Rao', specialty: 'General Practice',
    license: 'MAH-VC-2018-1234', verificationStatus: 'verified',
    supportedSpecies: ['Dog', 'Cat', 'Rabbit'], supportedAppointmentTypes: ['Home Visit', 'Vaccination', 'Teleconsultation'],
    serviceAreaIds: ['mumbai', 'pune'],
  },
  decisionStatus: 'recommended',
  eligibleCandidates: [
    { doctorId: 'demo_ad1', name: 'Dr. Anita Rao', specialty: 'General Practice', license: 'MAH-VC-2018-1234', verificationStatus: 'verified', supportedSpecies: ['Dog', 'Cat', 'Rabbit'], supportedAppointmentTypes: ['Home Visit', 'Vaccination'], serviceAreaIds: ['mumbai', 'pune'] },
    { doctorId: 'demo_ad2', name: 'Dr. Vikram Sethi', specialty: 'Surgery', license: 'DEL-VC-2019-5678', verificationStatus: 'verified', supportedSpecies: ['Dog', 'Cat', 'Horse', 'Cattle'], supportedAppointmentTypes: ['Home Visit', 'Surgery'], serviceAreaIds: ['delhi', 'jaipur'] },
  ],
  decisionFactors: [
    { label: 'Verification Status', passed: true, detail: 'Verified veterinarian' },
    { label: 'Species Support', passed: true, detail: 'Supports Dog' },
    { label: 'Appointment Type', passed: true, detail: 'Supports Home Visit and Vaccination' },
    { label: 'Service Area', passed: true, detail: 'Covers Mumbai service area' },
    { label: 'Availability', passed: true, detail: 'Available at requested time slot' },
  ],
  timestamp: new Date().toISOString(),
  reason: 'Dr. Anita Rao is verified, supports the required species and appointment type, and covers the client service area.',
};

type PageProps = {
  query: string; setQuery: (s: string) => void; filteredClients: typeof clients;
  selectedClient: number; setSelectedClient: (n: number) => void; navigate: (p: Page) => void;
  setModal: (s: string | null) => void; modal: string | null;
  paymentTab: 'all' | 'paid' | 'upcoming' | 'live'; setPaymentTab: (t: 'all' | 'paid' | 'upcoming' | 'live') => void;
  myPets: typeof clients extends never ? never : { name: string; species: string; breed: string; color: string; sex: string; age: string; weight: string; visits: number; lastVisit: string }[];
  setMyPets: (pets: any) => void;
  profile: { name: string; phone: string; email: string; address: string }; setProfile: (p: any) => void;
  pendingDocs: typeof pendingDoctors; setPendingDocs: (d: typeof pendingDoctors) => void;
  activeDocs: typeof activeDoctors; setActiveDocs: (d: typeof activeDoctors) => void;
};

function renderPage(page: Page, role: Role, props: any) {
  if (page === 'Dashboard') return <Dashboard role={role} navigate={props.navigate} pendingDocs={props.pendingDocs} />;
  if (page === 'Clients') return <ClientsPage {...props} />;
  if (page === 'Patients' || page === 'My Pets') return <PatientsPage role={role} {...props} />;
  if (page === 'Payments') return role === 'client' ? <ClientPaymentsPage paymentTab={props.paymentTab} setPaymentTab={props.setPaymentTab} /> : <AdminPaymentsPage />;
  if (page === 'Follow-ups') return <Followups />;
  if (page === 'Appointments' || page === 'Visits' || page === 'Schedule') return <AppointmentsPage role={role} setModal={props.setModal} authUserId={props.authUserId ?? ''} demoMode={props.demoMode} />;
  if (page === 'Medical Records') return <ClientMedicalRecords />;
  if (page === 'Prescriptions') return role === 'client' ? <ClientPrescriptions /> : <DoctorPrescriptions setModal={props.setModal} />;
  if (page === 'Subscription') return <ClientSubscription />;
  if (page === 'Profile') return <ClientProfile profile={props.profile} setProfile={props.setProfile} />;
  if (page === 'Doctor Approval') return <DoctorApproval pendingDocs={props.pendingDocs} setPendingDocs={props.setPendingDocs} activeDocs={props.activeDocs} setActiveDocs={props.setActiveDocs} setModal={props.setModal} />;
  if (page === 'Doctors') return <DoctorsList activeDocs={props.activeDocs} />;
  if (page === 'Subscriptions') return <AdminSubscriptions />;
  if (page === 'Notifications') return <NotificationsPage role={role} authUserId={props.authUserId ?? ''} demoMode={props.demoMode} navigate={props.navigate} />;
  if (page === 'Search') return <SearchPage role={role as 'doctor' | 'admin'} />;
  if (page === 'Breeding') return role === 'client' ? <BreedingPage myPets={props.myPets} /> : <DoctorBreedingSearch role={role as 'doctor' | 'admin'} />;
  // Shop routes
  if (page === 'Shop') return role === 'admin' ? <AdminShopDashboard /> : role === 'doctor' ? <DoctorShop isSubscriber={false} /> : <ShopHome isSubscriber={true} navigate={props.navigate} />;
  if (page === 'Shop Catalog') return <ShopCatalog isSubscriber={true} cart={props.cart} setCart={props.setCart} myPets={props.myPets} selectedPet={props.shopPet} setSelectedPet={props.setShopPet} navigate={props.navigate} />;
  if (page === 'Product Detail') return props.shopProduct ? <ProductDetail product={props.shopProduct} isSubscriber={true} onAdd={() => {}} onBack={() => props.navigate('Shop Catalog')} /> : <ShopCatalog isSubscriber={true} cart={props.cart} setCart={props.setCart} myPets={props.myPets} selectedPet={props.shopPet} setSelectedPet={props.setShopPet} navigate={props.navigate} />;
  if (page === 'Cart') return <Cart cart={props.cart} setCart={props.setCart} isSubscriber={true} navigate={props.navigate} />;
  if (page === 'Checkout') return <Checkout cart={props.cart} isSubscriber={true} navigate={props.navigate} onOrderPlaced={() => props.setCart([])} />;
  if (page === 'My Orders') return <MyOrders navigate={(p: string) => { const id = p.split(':')[1]; props.setShopOrderId(id); props.navigate('Order Detail' as Page); }} />;
  if (page === 'Order Detail') return props.shopOrderId ? <OrderDetail orderId={props.shopOrderId} onBack={() => props.navigate('My Orders')} /> : <MyOrders navigate={(p: string) => { const id = p.split(':')[1]; props.setShopOrderId(id); props.navigate('Order Detail' as Page); }} />;
  if (page === 'Shop Dashboard') return <AdminShopDashboard />;
  if (page === 'Shop Products') return <AdminProducts onAddProduct={() => props.setModal('Add Product')} />;
  if (page === 'Shop Orders') return <AdminOrders onOrderClick={(id: string) => { props.setAdminOrderId(id); props.navigate('Admin Order Detail' as Page); }} />;
  if (page === 'Shop Inventory') return <AdminInventory />;
  if (page === 'Admin Order Detail') return props.adminOrderId ? <AdminOrderDetail orderId={props.adminOrderId} onBack={() => props.navigate('Shop Orders')} /> : <AdminOrders onOrderClick={(id: string) => { props.setAdminOrderId(id); props.navigate('Admin Order Detail' as Page); }} />;
  // Orchestration routes
  if (page === 'Care Orchestration') return <CareOrchestrationPage role={role} appointmentStates={demoAppointmentStates} />;
  if (page === 'Clinical Context') return <ClinicalContextPage />;
  if (page === 'Audit Timeline') return <AuditTimelinePage role={role} />;
  if (page === 'Offline Sync') return <OfflineSyncPanel />;
  if (page === 'Identity Integrity') return <IdentityResolution role={role} />;
  if (page === 'Practitioner Onboarding') return <PractitionerOnboarding role={role} />;
  if (page === 'Onboarding Queue') return <PractitionerOnboarding role={role} />;
  if (page === 'Onboarding Audit') return <PractitionerOnboarding role={role} />;
  if (page === 'Notifications') return <NotificationsPage role={role} authUserId={props.authUserId ?? ''} demoMode={props.demoMode} navigate={props.navigate} />;
  return <GenericPage page={page} role={role} setModal={props.setModal} />;
}

function SearchBar({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder: string }) {
  return <div className="searchbar"><Search size={17} /><input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />{value && <button onClick={() => onChange('')}><X size={14} /></button>}</div>;
}

function Stat({ number, label, accent = '' }: { number: string; label: string; accent?: string }) {
  return <div className={`stat ${accent}`}><strong>{number}</strong><span>{label}</span></div>;
}

function ClientsPage({ query, setQuery, filteredClients, selectedClient, setSelectedClient }: any) {
  return <div className="clients-layout">
    <div className="list-column"><SearchBar value={query} onChange={setQuery} placeholder="Search by name, phone, email, pet name, species..." />
      <div className="client-list">{filteredClients.map((client: any, i: number) => (
        <button key={client.name} className={`client-card ${selectedClient === i ? 'selected' : ''}`} onClick={() => setSelectedClient(i)}>
          <div className="avatar">{client.initials}</div>
          <div className="card-main"><strong>{client.name}</strong><span className="cid-small">{client.clientId}</span><span>{client.city}</span><small>{client.pets}</small></div>
          <div className="last-visit"><small>Last visit</small><span>{client.last}</span></div>
        </button>
      ))}</div>
    </div>
    <ClientDetail client={filteredClients[selectedClient] ?? clients[0]} />
  </div>;
}

function ClientDetail({ client }: { client: typeof clients[number] }) {
  return <section className="detail-card">
    <div className="detail-head"><div className="avatar large">{client.initials}</div><div><h2>{client.name}</h2><p><span className="cid-badge-large">{client.clientId}</span> {client.city} · Joined {client.joined}</p></div></div>
    <div className="tabs"><button className="active">Profile</button><button>Pets (2)</button><button>Visits (5)</button><button>Rx (3)</button><button>Payments (3)</button></div>
    <div className="detail-content">
      <div className="info-grid">
        <div><label>CLIENT ID</label><strong className="cid-text">{client.clientId}</strong></div>
        <div><label>PHONE</label><strong>{client.phone}</strong></div>
        <div><label>EMAIL</label><strong>{client.email}</strong></div>
        <div className="wide"><label>ADDRESS</label><strong>{client.address}</strong></div>
      </div>
      <div className="mini-stats"><Stat number="2" label="Pets" /><Stat number="3" label="Visits" /><Stat number="27 Sept 2026" label="Next Visit" /></div>
    </div>
  </section>;
}

function PatientsPage({ role, myPets, setMyPets }: any) {
  const [selectedPatientIdx, setSelectedPatientIdx] = useState(0);
  const [patientQuery, setPatientQuery] = useState('');
  const [speciesPill, setSpeciesPill] = useState('All Species');

  if (role === 'client') {
    return <div className="patients-layout">
      <div className="patient-list">
        <div className="filter-row"><SearchBar value={patientQuery} onChange={setPatientQuery} placeholder="Search by name, species, breed..." /></div>
        {myPets.map((p: any, i: number) => (
          <button className="patient-card" key={p.name}>
            <div className="pet-icon"><PawPrint size={19} /></div>
            <div className="card-main"><strong>{p.name} <em className={`tag ${p.species.toLowerCase()}`}>{p.species}</em><span className="muted"> {p.sex}</span></strong><span>{p.breed} · {p.color}</span><small>{p.age} · {p.weight}</small></div>
            <div className="owner"><small>{p.visits} {p.visits === 1 ? 'visit' : 'visits'}</small><small>Last: {p.lastVisit}</small></div>
          </button>
        ))}
      </div>
      <div className="empty-detail"><PawPrint size={34} /><p>Select a pet to view details</p></div>
    </div>;
  }

  const filteredPatients = patients.filter((p) => {
    const q = patientQuery.toLowerCase();
    const matchesQuery = !q || `${p[0]} ${p[1]} ${p[2]} ${p[4]}`.toLowerCase().includes(q);
    const matchesSpecies = speciesPill === 'All Species' || p[1] === speciesPill;
    return matchesQuery && matchesSpecies;
  });
  const selectedPatient = filteredPatients[selectedPatientIdx] ?? filteredPatients[0];

  return <div className="patients-layout">
    <div className="patient-list">
      <div className="filter-row"><SearchBar value={patientQuery} onChange={(v) => { setPatientQuery(v); setSelectedPatientIdx(0); }} placeholder="Search by name, species, breed, owner..." />
        <div className="species-pills">{['All Species', 'Dog', 'Cat', 'Cattle', 'Horse', 'Goat', 'Rabbit', 'Elephant'].map((s) => <button className={speciesPill === s ? 'active' : ''} key={s} onClick={() => { setSpeciesPill(s); setSelectedPatientIdx(0); }}>{s}</button>)}</div>
      </div>
      {filteredPatients.map((p, i) => (
        <button className={`patient-card ${selectedPatientIdx === i ? 'selected' : ''}`} key={p[0]} onClick={() => setSelectedPatientIdx(i)}>
          <div className="pet-icon"><PawPrint size={19} /></div>
          <div className="card-main"><strong>{p[0]} <em className={`tag ${p[1].toLowerCase()}`}>{p[1]}</em><span className="muted"> {p[1] === 'Dog' ? 'Male' : 'Female'}</span></strong><span>{p[2]}</span><small>{p[3]}</small><span className="pid-small">{p[6] ?? ''}</span></div>
          <div className="owner"><strong>{p[4]}</strong><small>{p[5]}</small><small>Last: {p[5] === '2 visits' ? '15 Sept 2026' : 'No visits yet'}</small></div>
        </button>
      ))}
    </div>
    {selectedPatient ? <DoctorPatientDetail patient={selectedPatient} /> : <div className="empty-detail"><PawPrint size={34} /><p>Select a patient to view details</p></div>}
  </div>;
}

function ClientPaymentsPage({ paymentTab, setPaymentTab }: { paymentTab: 'all' | 'paid' | 'upcoming' | 'live'; setPaymentTab: (t: 'all' | 'paid' | 'upcoming' | 'live') => void }) {
  const totalPaid = 14000;
  return <>
    <div className="stats-row">
      <Stat number="₹14,000" label="Total Paid" accent="green" />
      <Stat number="₹13,000" label="Upcoming" accent="orange" />
      <Stat number={String(livePayments.length)} label="Live Payments" accent="blue" />
    </div>
    <div className="payment-tabs">
      <button className={paymentTab === 'all' ? 'active' : ''} onClick={() => setPaymentTab('all')}>All ({paidPayments.length + upcomingPayments.length + livePayments.length})</button>
      <button className={paymentTab === 'paid' ? 'active' : ''} onClick={() => setPaymentTab('paid')}>Paid ({paidPayments.length})</button>
      <button className={paymentTab === 'upcoming' ? 'active' : ''} onClick={() => setPaymentTab('upcoming')}>Upcoming ({upcomingPayments.length})</button>
      <button className={paymentTab === 'live' ? 'active' : ''} onClick={() => setPaymentTab('live')}>Live ({livePayments.length})</button>
    </div>
    {(paymentTab === 'all' || paymentTab === 'paid') && (
      <div className="payment-section">
        <h3 className="payment-section-title"><Check size={16} /> Paid <span className="count">({paidPayments.length})</span></h3>
        <div className="table-card">
          <div className="table-head"><span>SERVICE</span><span></span><span>AMOUNT</span><span>DATE</span><span>STATUS</span><span>INVOICE</span></div>
          {paidPayments.map((p) => <div className="table-row" key={p.service}><div><strong>{p.service}</strong><small>{p.method}</small></div><div><span></span></div><strong>{p.amount}</strong><span>{p.date}</span><span className="status paid">PAID</span><button className="link"><FileText size={13} /> Invoice</button></div>)}
        </div>
      </div>
    )}
    {(paymentTab === 'all' || paymentTab === 'upcoming') && (
      <div className="payment-section">
        <h3 className="payment-section-title"><CalendarDays size={16} /> Upcoming <span className="count">({upcomingPayments.length})</span></h3>
        <div className="table-card">
          <div className="table-head"><span>SERVICE</span><span></span><span>AMOUNT</span><span>DATE</span><span>STATUS</span><span></span></div>
          {upcomingPayments.map((p) => <div className="table-row" key={p.service}><div><strong>{p.service}</strong><small>Due {p.due}</small></div><div><span></span></div><strong>{p.amount}</strong><span>{p.due}</span><span className="status pending">UPCOMING</span><button className="link">Details</button></div>)}
        </div>
      </div>
    )}
    {(paymentTab === 'all' || paymentTab === 'live') && (
      <div className="payment-section">
        <h3 className="payment-section-title"><AlertTriangle size={16} /> Live — Payment Required <span className="count">({livePayments.length})</span></h3>
        <div className="table-card">
          <div className="table-head"><span>SERVICE</span><span></span><span>AMOUNT</span><span>DATE</span><span>STATUS</span><span></span></div>
          {livePayments.map((p) => <div className="table-row" key={p.service}><div><strong>{p.service}</strong><small>Payment required now</small></div><div><span></span></div><strong>{p.amount}</strong><span>Now</span><span className="status live">LIVE</span><button className="primary" style={{ padding: '6px 12px', fontSize: '11px' }}>Pay Now</button></div>)}
        </div>
      </div>
    )}
  </>;
}

function AdminPaymentsPage() {
  const total = allPayments.reduce((s, p) => s + parseInt(p.amount.replace(/[^0-9]/g, '')), 0);
  return <>
    <div className="stats-row"><Stat number={`₹${total.toLocaleString('en-IN')}`} label="Total Revenue" accent="green" /><Stat number="0" label="Pending" accent="orange" /><Stat number={String(allPayments.length)} label="Transactions" /></div>
    <div className="table-card">
      <div className="table-head"><span>CLIENT</span><span>SERVICE</span><span>AMOUNT</span><span>DATE</span><span>STATUS</span><span></span></div>
      {allPayments.map((p) => <div className="table-row" key={p.service}><div><strong>{p.client}</strong><small className="cid-small">{p.clientId ?? ''}</small></div><div><span>{p.service}</span><small>{p.method}</small></div><strong>{p.amount}</strong><span>{p.date}</span><span className="status paid">PAID</span><button className="link"><FileText size={13} /> View</button></div>)}
    </div>
  </>;
}

function AdminSubscriptions() {
  return <>
    <div className="stats-row"><Stat number={String(allSubs.filter(s => s.status === 'Active').length)} label="Active" accent="green" /><Stat number={String(allSubs.filter(s => s.status === 'Pending').length)} label="Pending" accent="orange" /><Stat number="₹41,000" label="MRR" accent="green" /></div>
    <div className="table-card">
      <div className="table-head"><span>CLIENT</span><span>PLAN</span><span>PRICE</span><span>START DATE</span><span>STATUS</span><span></span></div>
      {allSubs.map((s) => <div className="table-row" key={s.client}><div><strong>{s.client}</strong><small className="cid-small">{s.clientId ?? ''}</small></div><div><span>{s.plan}</span></div><strong>{s.price}</strong><span>{s.start}</span><span className={`status ${s.status.toLowerCase()}`}>{s.status.toUpperCase()}</span></div>)}
    </div>
  </>;
}

function ClientMedicalRecords() {
  return <>
    <div className="searchbar" style={{ marginBottom: '14px' }}><Search size={17} /><input placeholder="Search by pet name, diagnosis, date..." /></div>
    {clinicalRecords.map((r) => (
      <div className="record-card" key={r.pet + r.date}>
        <div className="record-pet">
          <div className="pet-icon"><PawPrint size={16} /></div>
          <div><strong>{r.pet}</strong><small>{r.species} · {r.breed} · Owner: Priya Sharma</small></div>
        </div>
        <div className="record-grid">
          <div><label>VISIT DATE</label><strong>{r.date}</strong></div>
          <div><label>REASON</label><strong>{r.reason}</strong></div>
          <div><label>DIAGNOSIS</label><strong>{r.diagnosis}</strong></div>
          <div><label>TREATMENT</label><strong>{r.treatment}</strong></div>
          <div><label>NOTES</label><strong>{r.notes}</strong></div>
          <div><label>FOLLOW-UP</label><strong>{r.followup}</strong></div>
        </div>
      </div>
    ))}
  </>;
}

function ClientPrescriptions() {
  return <>
    <div className="rx-notice"><AlertTriangle size={16} /><p>Prescriptions are created by your veterinarian. You can view and download them but cannot create or edit prescriptions.</p></div>
    {prescriptions.map((r) => (
      <div className="rx-card" key={r.pet + r.date}>
        <div className="pet-icon"><PawPrint size={16} /></div>
        <div><strong>{r.pet} <span className="dot">·</span> <small>{r.vet} · {r.date}</small></strong>
          <div className="rx-meds">{r.meds}</div>
          <small>Status: <em className={`status ${r.status === 'Active' ? 'confirmed' : 'pending'}`}>{r.status.toUpperCase()}</em></small>
        </div>
        <div className="rx-actions"><button className="link"><Download size={13} /> Download PDF</button><button className="link">View Details</button></div>
      </div>
    ))}
  </>;
}

function DoctorPrescriptions({ setModal }: { setModal: (s: string | null) => void }) {
  return <>
    <div className="table-card">
      <div className="table-head"><span>PET</span><span>MEDICATION</span><span>VET</span><span>DATE</span><span>STATUS</span><span></span></div>
      {prescriptions.map((r) => <div className="table-row" key={r.pet + r.date}><div><strong>{r.pet}</strong></div><div><span>{r.meds}</span></div><div><span>{r.vet}</span></div><span>{r.date}</span><span className={`status ${r.status === 'Active' ? 'confirmed' : 'pending'}`}>{r.status.toUpperCase()}</span><button className="link"><FileText size={13} /> View</button></div>)}
    </div>
  </>;
}

function ClientSubscription() {
  return <>
    <div className="detail-card" style={{ minHeight: 'auto', marginBottom: '16px' }}>
      <div className="detail-head"><div className="avatar large" style={{ background: '#112b73', color: '#fff' }}>G</div><div><h2>Current Subscription</h2><p>Gold Plan · Annual · Active since 1 Jan 2026</p></div></div>
      <div className="detail-content">
        <div className="info-grid">
          <div><label>PLAN</label><strong>Gold — Annual</strong></div>
          <div><label>PRICE</label><strong>₹12,000 / year</strong></div>
          <div><label>STATUS</label><strong style={{ color: '#0b9b55' }}>Active</strong></div>
          <div><label>RENEWS ON</label><strong>1 Jan 2027</strong></div>
        </div>
      </div>
    </div>
    <div className="panel">
      <div className="panel-title"><h3>Available Plans</h3></div>
      <div className="plan-grid">
        {plans.map((p) => (
          <div key={p.name} className={`plan-card ${p.current ? 'current' : ''}`}>
            {p.current && <span className="current-badge">Current Plan</span>}
            <h4>{p.name}</h4>
            <div className="price">{p.price}<small>{p.period}</small></div>
            <ul>{p.benefits.map((b) => <li key={b}><Check size={14} />{b}</li>)}</ul>
            {p.current ? <button className="secondary" disabled style={{ opacity: 0.6 }}>Current Plan</button> : <button className="primary">Select Plan</button>}
          </div>
        ))}
      </div>
    </div>
  </>;
}

function ClientProfile({ profile, setProfile }: { profile: { name: string; phone: string; email: string; address: string }; setProfile: (p: any) => void }) {
  const [form, setForm] = useState(profile);
  const clientId = 'VW-CL-000001';
  return <>
    <section className="detail-card" style={{ minHeight: 'auto', marginBottom: '16px' }}>
      <div className="detail-head"><div className="avatar large">P</div><div><h2>{profile.name}</h2><p><span className="cid-badge-large">{clientId}</span> Mumbai, Maharashtra · Joined Mar 2025</p></div></div>
      <div className="detail-content">
        <div className="info-grid" style={{ marginBottom: '16px' }}>
          <div><label>CLIENT ID</label><strong className="cid-text">{clientId}</strong></div>
          <div><label>STATUS</label><strong style={{ color: '#0b9b55' }}>Active</strong></div>
        </div>
        <div className="profile-form">
          <label>Name<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
          <label>Phone<input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></label>
          <label>Email<input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label>
          <label className="wide">Address<input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></label>
          <div className="save-row">
            <button className="secondary" onClick={() => setForm(profile)}>Cancel</button>
            <button className="primary" onClick={() => setProfile(form)}><Check size={16} /> Save Changes</button>
          </div>
        </div>
      </div>
    </section>
    <GpsLocationPicker clientId={clientId} />
  </>;
}

function DoctorApproval({ pendingDocs, setPendingDocs, activeDocs, setActiveDocs, setModal }: any) {
  const [approving, setApproving] = useState<string | null>(null);
  if (pendingDocs.length === 0) return <div className="empty-state"><Check size={40} /><h3>No pending approvals</h3><p>All doctor applications have been reviewed.</p></div>;
  return <>
    <div className="panel" style={{ marginBottom: '16px' }}>
      <div className="panel-title"><h3>Pending Doctor Applications</h3><span className="status pending">{pendingDocs.length} PENDING</span></div>
    </div>
    {pendingDocs.map((d: any, i: number) => (
      <div className="doctor-card" key={d.name}>
        <div className="pet-icon"><Stethoscope size={19} /></div>
        <div className="doctor-info">
          <strong>{d.name}</strong><br /><small>{d.specialty} · Applied {d.applied}</small>
          <div className="doctor-details">
            <div><label>EMAIL</label><strong>{d.email}</strong></div>
            <div><label>PHONE</label><strong>{d.phone}</strong></div>
            <div><label>LICENSE</label><strong>{d.license}</strong></div>
            <div><label>EXPERIENCE</label><strong>{d.experience}</strong></div>
            <div><label>CLINIC</label><strong>{d.clinic}</strong></div>
          </div>
        </div>
        <div className="doctor-actions">
          <button className="approve-btn" disabled={approving === d.doctorId} onClick={async () => {
            setApproving(d.doctorId);
            const adminId = (window as any).__vetwiseUserId ?? 'demo_admin';
            const { error } = await dbApproveDoctor(d.doctorId, adminId);
            if (error) {
              setActiveDocs([...activeDocs, { ...d, joined: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) }]);
            }
            setPendingDocs(pendingDocs.filter((_: any, idx: number) => idx !== i));
            setApproving(null);
          }}><Check size={14} /> {approving === d.doctorId ? 'Approving...' : 'Approve'}</button>
          <button className="danger-btn" disabled={approving === d.doctorId} onClick={async () => {
            setApproving(d.doctorId);
            await dbRejectDoctor(d.doctorId, 'Not specified');
            setPendingDocs(pendingDocs.filter((_: any, idx: number) => idx !== i));
            setApproving(null);
          }}><Ban size={14} /> Reject</button>
        </div>
      </div>
    ))}
  </>;
}

function DoctorsList({ activeDocs }: { activeDocs: typeof activeDoctors }) {
  return <>
    <div className="stats-row"><Stat number={String(activeDocs.length)} label="Active Doctors" /><Stat number="2" label="Specialties" /><Stat number="0" label="Suspended" /></div>
    <div className="table-card">
      <div className="table-head"><span>NAME</span><span>SPECIALTY</span><span>LICENSE</span><span>JOINED</span></div>
      {activeDocs.map((d) => <div className="table-row" key={d.name}><div><strong>{d.name}</strong><small>{d.email}</small></div><div><span>{d.specialty}</span></div><div><span>{d.license}</span></div><div><span>{d.joined}</span></div></div>)}
    </div>
  </>;
}

function Followups() {
  const rows = [['Whiskers', 'Priya Sharma', 'Skin infection follow-up — check healing progress', 'OVERDUE'], ['Bruno', 'Priya Sharma', 'Post-vaccination check — verify no adverse reaction', 'PENDING'], ['Nandi', 'Ramesh Patel', 'Hoof rot — confirm healing, check temperature', 'PENDING'], ['Raja', 'Suresh Kumar', 'Post-dehydration — confirm recovery', 'PENDING']];
  return <>
    <div className="stats-row"><Stat number="1" label="Overdue" accent="red" /><Stat number="4" label="Pending" accent="blue" /><Stat number="0" label="Completed" accent="green" /></div>
    <div className="follow-list">{rows.map((r) => (
      <div className="follow-card" key={r[0]}>
        <div className="pet-icon"><PawPrint size={18} /></div>
        <div><strong>{r[0]} <span className="dot">·</span> <small>{r[1]}</small> <em className={`status ${r[3].toLowerCase()}`}>{r[3]}</em></strong><p>{r[2]}</p><small>Previous visit: 2 Sept 2026　 Follow-up due: <b>{r[3] === 'OVERDUE' ? '23 Sep 2026' : '29 Sep 2026'}</b></small></div>
        <div className="follow-actions"><button className="link">Open Patient</button><button className="link">Open Client</button><button className="link">Open Record</button></div>
      </div>
    ))}</div>
  </>;
}

function AppointmentsPage({ role, setModal, authUserId, demoMode }: { role: Role; setModal: (s: string | null) => void; authUserId: string; demoMode: boolean }) {
  const [appointments, setAppointments] = useState<any[]>(demoMode ? allAppointments : []);
  const [loading, setLoading] = useState(!demoMode);

  useEffect(() => {
    if (demoMode) { setAppointments(allAppointments); return; }
    if (!authUserId) return;
    setLoading(true);
    if (role === 'client') {
      fetchClientsByUser(authUserId).then(({ data: clientsData }) => {
        if (clientsData && clientsData.length > 0) {
          fetchAppointmentsByClient(clientsData[0].client_id).then(({ data, error }) => {
            if (!error && data) setAppointments(data);
            setLoading(false);
          });
        } else { setLoading(false); }
      });
    } else {
      fetchAppointments().then(({ data, error }) => {
        if (!error && data) setAppointments(data);
        setLoading(false);
      });
    }
  }, [authUserId, demoMode, role]);

  if (loading) return <div className="empty-state"><Loader2 size={28} className="spin" /><p>Loading appointments...</p></div>;

  if (appointments.length === 0) {
    if (role === 'client') return <div className="empty-state"><CalendarDays size={40} /><h3>No upcoming visits</h3><p>Book a visit for your pet and keep their care on track.</p><button className="primary" onClick={() => setModal('Book a Visit')}><Plus size={16} /> Book appointment</button></div>;
    return <div className="empty-state"><CalendarDays size={40} /><h3>No appointments</h3><p>Appointments will appear here once they are booked.</p></div>;
  }

  return <>
    <div className="appointment-toolbar"><div className="date-switch"><button>‹</button><strong>Today, {new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</strong><button>›</button></div><div className="view-toggle"><button className="active">List</button><button>Calendar</button></div></div>
    <div className="appointment-list">{appointments.map((a, i) => {
      const petName = a.patients?.name ?? a.pet ?? 'Unknown';
      const clientName = a.clients?.full_name ?? a.client ?? '';
      const apptTime = a.preferred_time ?? a.time ?? '';
      const apptReason = a.reason ?? '';
      const apptStatus = a.status ?? 'Pending';
      const apptLocation = a.visit_location ?? a.visitLocation ?? 'Address not set';
      const apptPid = a.patient_id ?? a.patientId ?? '';
      const apptCid = a.client_id ?? a.clientId ?? '';
      return (
        <div className="appointment-card appt-with-location" key={a.id ?? i}>
          <div className="time">{apptTime}<small>30 min</small></div>
          <div className="pet-icon"><PawPrint size={18} /></div>
          <div className="appt-main"><strong>{petName}</strong><span>{clientName}</span><small>{apptReason}</small>
            <div className="appt-location"><MapPin size={11} /> {apptLocation}</div>
          </div>
          <div className="appt-ids"><small className="pid-small">{apptPid}</small><small className="cid-small">{apptCid}</small></div>
          <span className={`status ${apptStatus.toLowerCase()}`}>{apptStatus.toUpperCase()}</span>
          <button className="more"><MoreHorizontal size={19} /></button>
        </div>
      );
    })}</div>
  </>;
}

function Dashboard({ role, navigate, pendingDocs }: { role: Role; navigate: (p: Page) => void; pendingDocs: typeof pendingDoctors }) {
  if (role === 'admin') {
    return <div className="dashboard">
      <div className="welcome"><div><p className="eyebrow">ADMIN OVERVIEW</p><h2>Practice at a glance.</h2></div></div>
      <div className="stats-row four"><Stat number={String(activeDoctors.length)} label="Active Doctors" /><Stat number={String(pendingDocs.length)} label="Pending Approvals" accent="orange" /><Stat number={String(clients.length)} label="Clients" /><Stat number={String(patients.length)} label="Patients" /></div>
      <div className="stats-row"><Stat number={String(allAppointments.length)} label="Appointments" /><Stat number="₹42,500" label="Total Revenue" accent="green" /><Stat number={String(allSubs.filter(s => s.status === 'Active').length)} label="Active Subscriptions" /></div>
      <div className="dashboard-grid">
        <section className="panel"><div className="panel-title"><h3>Pending Doctor Approvals</h3><button className="link" onClick={() => navigate('Doctor Approval')}>View all <ArrowUpRight size={14} /></button></div>
          {pendingDocs.length > 0 ? pendingDocs.map((d) => <div className="simple-row" key={d.name}><div className="pet-icon"><Stethoscope size={16} /></div><div><strong>{d.name}</strong><small>{d.specialty} · Applied {d.applied}</small></div><span className="status pending">PENDING</span></div>) : <p style={{ color: '#a4aebe', fontSize: '13px', padding: '12px 0' }}>No pending approvals.</p>}
        </section>
        <section className="panel"><div className="panel-title"><h3>Recent Payments</h3></div>
          {allPayments.slice(0, 3).map((p) => <div className="simple-row" key={p.service}><div className="pet-icon"><DollarSign size={16} /></div><div><strong>{p.client}</strong><small>{p.service} · {p.amount}</small></div><span className="status paid">PAID</span></div>)}
        </section>
      </div>
      <div className="dashboard-grid">
        <section className="panel"><div className="panel-title"><h3>Quick Actions</h3></div>
          <button className="quick-action" onClick={() => navigate('Shop Orders')}><Package size={16} />Manage shop orders<ArrowUpRight size={14} /></button>
          <button className="quick-action" onClick={() => navigate('Shop Products')}><Package size={16} />Manage products<ArrowUpRight size={14} /></button>
          <button className="quick-action" onClick={() => navigate('Doctor Approval')}><Activity size={16} />Review doctor approvals<ArrowUpRight size={14} /></button>
        </section>
      </div>
    </div>;
  }
  if (role === 'client') {
    return <div className="dashboard">
      <div className="welcome"><div><p className="eyebrow">YOUR PET CARE</p><h2>How are your pets doing today?</h2></div><button className="primary" onClick={() => navigate('Visits')}><Plus size={16} /> Book a visit</button></div>
      <div className="stats-row four"><Stat number="2" label="My Pets" /><Stat number="0" label="Upcoming visits" /><Stat number="0" label="Active prescriptions" /><Stat number="₹0" label="Upcoming payments" accent="orange" /></div>
      <div className="dashboard-grid">
        <section className="panel"><div className="panel-title"><h3>Your pets</h3><button className="link" onClick={() => navigate('My Pets')}>View all <ArrowUpRight size={14} /></button></div>
          {[{ n: 'Bruno', v: 2, l: '15 Sept 2026' }, { n: 'Whiskers', v: 1, l: '2 Sept 2026' }].map((p) => <div className="simple-row" key={p.n}><div className="pet-icon"><PawPrint size={16} /></div><div><strong>{p.n} · Last visit {p.l}</strong><small>{p.v} visits</small></div><span className="status confirmed">ACTIVE</span></div>)}
        </section>
        <section className="panel"><div className="panel-title"><h3>Quick actions</h3></div>
          <button className="quick-action" onClick={() => navigate('Shop')}><ShoppingCart size={16} />Shop for your pets<ArrowUpRight size={14} /></button>
          <button className="quick-action" onClick={() => navigate('Medical Records')}><Activity size={16} />View medical records<ArrowUpRight size={14} /></button>
          <button className="quick-action" onClick={() => navigate('My Orders')}><Package size={16} />View my orders<ArrowUpRight size={14} /></button>
        </section>
      </div>
      <ShopHomeSections navigate={navigate} />
    </div>;
  }
  return <div className="dashboard">
    <div className="welcome"><div><p className="eyebrow">GOOD MORNING, DOCTOR</p><h2>Here's what needs your attention.</h2></div><button className="primary" onClick={() => navigate('Appointments')}><Plus size={16} /> New appointment</button></div>
    <div className="stats-row four"><Stat number="12" label="Today's appointments" /><Stat number="5" label="Upcoming visits" /><Stat number="4" label="Prescriptions" /><Stat number="₹42,500" label="Total received" accent="green" /></div>
    <div className="dashboard-grid">
      <section className="panel"><div className="panel-title"><h3>Upcoming appointments</h3><button className="link" onClick={() => navigate('Appointments')}>View all <ArrowUpRight size={14} /></button></div>
        {['Bruno · Vaccination', 'Whiskers · Skin follow-up', 'Nandi · Routine check-up'].map((x, i) => <div className="simple-row" key={x}><div className="pet-icon"><PawPrint size={16} /></div><div><strong>{x}</strong><small>{['15 Sept 2026 · 9:00 AM', '29 Sept 2026 · 10:30 AM', '4 Oct 2026 · 12:00 PM'][i]}</small></div><span className={i === 0 ? 'status confirmed' : 'status pending'}>{i === 0 ? 'CONFIRMED' : 'UPCOMING'}</span></div>)}
      </section>
      <section className="panel"><div className="panel-title"><h3>Quick actions</h3></div>
        {['View medical records', 'Download prescriptions', 'Update profile'].map((x) => <button className="quick-action" key={x}><Activity size={16} />{x}<ArrowUpRight size={14} /></button>)}
      </section>
    </div>
  </div>;
}

function ShopHomeSections({ navigate }: { navigate: (p: Page) => void }) {
  const cats = [
    { name: 'Medicines', icon: <Pill size={20} /> },
    { name: 'Pet Food', icon: <Package size={20} /> },
    { name: 'Animal Food', icon: <Package size={20} /> },
    { name: 'Supplements', icon: <Heart size={20} /> },
    { name: 'Vitamins', icon: <ShieldCheck size={20} /> },
    { name: 'Grooming', icon: <Star size={20} /> },
    { name: 'Preventive Care', icon: <Shield size={20} /> },
    { name: 'Healthcare', icon: <Stethoscope size={20} /> },
  ];
  return <>
    <section className="shop-home-section">
      <div className="shop-section-head">
        <div><p className="eyebrow" style={{ color: '#4365a3' }}>VETWISE SHOP</p><h3>VetWise Veterinary Shop</h3><p className="shop-section-sub">Veterinary medicines, nutrition, supplements and healthcare products for pets and animals.</p></div>
        <button className="primary" onClick={() => navigate('Shop Catalog')}><ShoppingCart size={16} /> Shop Now</button>
      </div>
      <div className="shop-cat-grid">
        {cats.map((c) => (
          <button key={c.name} className="shop-cat-card" onClick={() => navigate('Shop Catalog')}>
            <div className="shop-cat-icon">{c.icon}</div>
            <span>{c.name}</span>
          </button>
        ))}
      </div>
    </section>

    <section className="shop-sub-promo">
      <div className="shop-sub-promo-content">
        <span className="shop-promo-badge">10% OFF</span>
        <div><h3>VetWise Subscribers Save 10%</h3><p>Active VetWise subscribers get 10% off eligible medicines, pet food and supplements.</p></div>
      </div>
      <div className="shop-sub-promo-actions">
        <button className="primary" onClick={() => navigate('Shop Catalog')}><ShoppingCart size={14} /> Shop Now</button>
        <button className="secondary" onClick={() => navigate('Subscription')}>View Subscription</button>
      </div>
    </section>

    <section className="shop-about-section">
      <h3>About VetWise</h3>
      <p className="shop-about-text">VetWise brings veterinary care, appointments, prescriptions, animal health records and veterinary products together in one platform.</p>
      <div className="shop-about-grid">
        <div className="shop-about-card"><Stethoscope size={22} /><strong>Veterinary Care</strong><small>Appointments and veterinary consultations.</small></div>
        <div className="shop-about-card"><Package size={22} /><strong>Digital Animal Records</strong><small>Keep animal health information organized.</small></div>
        <div className="shop-about-card"><Pill size={22} /><strong>Prescriptions</strong><small>Access veterinary prescriptions and treatment information.</small></div>
        <div className="shop-about-card"><ShoppingCart size={22} /><strong>Veterinary Shop</strong><small>Buy medicines, food, supplements and animal healthcare products.</small></div>
        <div className="shop-about-card"><ShieldCheck size={22} /><strong>Subscriber Benefits</strong><small>Active subscribers receive 10% off eligible Shop products.</small></div>
      </div>
    </section>
  </>;
}

function SearchPage({ role }: { role: 'doctor' | 'admin' }) {
  const [selectedPatient, setSelectedPatient] = useState<string | null>(null);
  if (selectedPatient) {
    return <PatientDetailPanel patientId={selectedPatient} role={role} onClose={() => setSelectedPatient(null)} />;
  }
  return <PatientSearch role={role} onSelectPatient={setSelectedPatient} />;
}

function BreedingPage({ myPets }: { myPets: any[] }) {
  const [selectedPet, setSelectedPet] = useState<number>(0);
  const eligiblePets = myPets.filter((p: any) => p.breedingEligible);
  if (eligiblePets.length === 0) {
    return <div className="empty-state"><Heart size={40} /><h3>No breeding-enabled animals</h3><p>Enable breeding tracking when adding or editing an animal to see breeding records here.</p></div>;
  }
  const pet = eligiblePets[selectedPet] ?? eligiblePets[0];
  return <div className="patients-layout">
    <div className="patient-list">
      {eligiblePets.map((p: any, i: number) => (
        <button key={p.name} className={`patient-card ${selectedPet === i ? 'selected' : ''}`} onClick={() => setSelectedPet(i)}>
          <div className="pet-icon"><PawPrint size={19} /></div>
          <div className="card-main">
            <strong>{p.name} <em className={`tag ${p.species.toLowerCase()}`}>{p.species}</em></strong>
            <span className="pid-small">{p.patientId ?? ''}</span>
            <span>{p.breed}</span>
          </div>
        </button>
      ))}
    </div>
    <BreedingPanel patientId={pet.patientId ?? 'VW-CL-000001-P01'} patientName={pet.name} species={pet.species} breedingEligible={true} role="client" />
  </div>;
}

function DoctorPatientDetail({ patient }: { patient: typeof patients[number] }) {
  const [tab, setTab] = useState<'overview' | 'medical' | 'breeding' | 'records'>('overview');
  const name = patient[0] as string;
  const species = patient[1] as string;
  const breedInfo = patient[2] as string;
  const ageWeight = patient[3] as string;
  const ownerName = patient[4] as string;
  const visits = patient[5] as string;
  const pid = patient[6] as string;
  const client = clients.find((c) => c.clientId === pid?.split('-P')[0]);
  const clinicalForPatient = clinicalRecords.filter((r) => r.patientId === pid);
  const rxForPatient = prescriptions.filter((r) => r.patientId === pid);

  return <section className="detail-card">
    <div className="detail-head">
      <div className="pet-icon large"><PawPrint size={24} /></div>
      <div>
        <h2>{name}</h2>
        <p><span className="pid-badge">{pid}</span> <em className={`tag ${species.toLowerCase()}`}>{species}</em> <span className="muted">{breedInfo}</span></p>
        <p className="owner-line"><small>Owner: <strong>{ownerName}</strong></small> {client && <small className="cid-badge">{client.clientId}</small>}</p>
      </div>
    </div>
    <div className="tabs">
      <button className={tab === 'overview' ? 'active' : ''} onClick={() => setTab('overview')}>Overview</button>
      <button className={tab === 'medical' ? 'active' : ''} onClick={() => setTab('medical')}>Medical</button>
      <button className={tab === 'breeding' ? 'active' : ''} onClick={() => setTab('breeding')}>Breeding</button>
      <button className={tab === 'records' ? 'active' : ''} onClick={() => setTab('records')}>Records ({clinicalForPatient.length})</button>
    </div>
    <div className="detail-content">
      {tab === 'overview' && <>
        <div className="info-grid">
          <div><label>PATIENT ID</label><strong className="pid-text">{pid}</strong></div>
          <div><label>SPECIES</label><strong>{species}</strong></div>
          <div><label>BREED</label><strong>{breedInfo.split(' · ')[0]}</strong></div>
          <div><label>SEX</label><strong>{species === 'Dog' ? 'Male' : 'Female'}</strong></div>
          <div><label>AGE</label><strong>{ageWeight.split(' · ')[0]}</strong></div>
          <div><label>WEIGHT</label><strong>{ageWeight.split(' · ')[1] ?? 'Not recorded'}</strong></div>
          <div><label>VISITS</label><strong>{visits}</strong></div>
          <div><label>STATUS</label><strong>Active</strong></div>
        </div>
        {client && <div className="owner-section" style={{ marginTop: '16px' }}>
          <h4 style={{ fontFamily: 'Manrope', fontSize: '14px', margin: '0 0 10px', color: '#132f65' }}>Owner / Client</h4>
          <div className="info-grid">
            <div><label>CLIENT ID</label><strong className="cid-text">{client.clientId}</strong></div>
            <div><label>NAME</label><strong>{client.name}</strong></div>
            <div><label>PHONE</label><strong>{client.phone}</strong></div>
            <div><label>EMAIL</label><strong>{client.email}</strong></div>
            <div className="wide"><label>ADDRESS</label><strong>{client.address}</strong></div>
          </div>
        </div>}
      </>}
      {tab === 'medical' && <div className="info-grid">
        <div className="wide"><label>ALLERGIES</label><strong>None known</strong></div>
        <div className="wide"><label>EXISTING CONDITIONS</label><strong>None</strong></div>
        <div className="wide"><label>VACCINATIONS</label><strong>Rabies (Jan 2026), DHPP (Jan 2026)</strong></div>
        <div className="wide"><label>CURRENT MEDICATIONS</label><strong>Multivitamin supplement</strong></div>
        <div className="wide"><label>MEDICAL HISTORY</label><strong>Routine vaccinations up to date</strong></div>
        <div className="wide"><label>SPECIAL REQUIREMENTS</label><strong>Sensitive stomach — avoid dairy</strong></div>
      </div>}
      {tab === 'breeding' && <BreedingPanel patientId={pid} patientName={name} species={species} breedingEligible={species !== 'Cat' && species !== 'Rabbit'} role="doctor" />}
      {tab === 'records' && <>
        {clinicalForPatient.length === 0 ? <p className="empty-hint">No clinical records for this patient.</p> : clinicalForPatient.map((r) => (
          <div className="record-card" key={r.date}>
            <div className="record-pet"><div className="pet-icon"><FileText size={16} /></div><div><strong>{r.reason}</strong><small>{r.date}</small></div></div>
            <div className="record-grid">
              <div><label>DIAGNOSIS</label><strong>{r.diagnosis}</strong></div>
              <div><label>TREATMENT</label><strong>{r.treatment}</strong></div>
              <div><label>NOTES</label><strong>{r.notes}</strong></div>
              <div><label>FOLLOW-UP</label><strong>{r.followup}</strong></div>
            </div>
          </div>
        ))}
      </>}
    </div>
  </section>;
}

function DoctorBreedingSearch({ role }: { role: 'doctor' | 'admin' }) {
  const [query, setQuery] = useState('');
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);

  const breedingPatients = patients.filter((p) => {
    const species = p[1] as string;
    return species !== 'Cat' && species !== 'Rabbit';
  });
  const filtered = breedingPatients.filter((p) => {
    if (!query.trim()) return true;
    const q = query.toLowerCase();
    return `${p[0]} ${p[1]} ${p[2]} ${p[4]} ${p[6]}`.toLowerCase().includes(q);
  });

  if (selectedPatientId) {
    const patient = patients.find((p) => p[6] === selectedPatientId);
    if (patient) {
      return <div>
        <button className="secondary" style={{ marginBottom: '12px' }} onClick={() => setSelectedPatientId(null)}>Back to Breeding List</button>
        <DoctorPatientDetail patient={patient} />
      </div>;
    }
  }

  return <>
    <div className="searchbar" style={{ marginBottom: '14px' }}>
      <Search size={17} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search breeding animals by name, breed, species, owner, Patient ID..." />
      {query && <button onClick={() => setQuery('')}><X size={14} /></button>}
    </div>
    <div className="search-meta" style={{ marginBottom: '12px' }}>
      <small>{role === 'doctor' ? 'Showing breeding-eligible animals you are authorized to access.' : 'Admin access: all breeding-eligible animals.'}</small>
    </div>
    <div className="table-card">
      <div className="table-head"><span>PATIENT</span><span>SPECIES</span><span>BREED</span><span>OWNER</span><span>PATIENT ID</span><span></span></div>
      {filtered.map((p) => (
        <div className="table-row" key={p[6] as string}>
          <div><strong>{p[0]}</strong></div>
          <div><em className={`tag ${(p[1] as string).toLowerCase()}`}>{p[1]}</em></div>
          <div><span>{(p[2] as string).split(' · ')[0]}</span></div>
          <div><strong>{p[4]}</strong></div>
          <div><span className="pid-small">{p[6]}</span></div>
          <button className="link" onClick={() => setSelectedPatientId(p[6] as string)}>View Details <ArrowUpRight size={12} /></button>
        </div>
      ))}
    </div>
  </>;
}

function SettingsPage({ role }: { role: Role }) {
  const roleLabel = role === 'admin' ? 'Administrator' : role === 'doctor' ? 'Veterinarian' : role === 'frontdesk' ? 'Front Desk' : 'Client';
  return <div className="dashboard">
    <div className="welcome"><div><p className="eyebrow">ACCOUNT SETTINGS</p><h2>Manage your {roleLabel} account.</h2></div></div>
    <div className="dashboard-grid">
      <section className="panel">
        <div className="panel-title"><h3>Profile Information</h3></div>
        <div className="profile-form" style={{ maxWidth: 'none' }}>
          <label>Name<input defaultValue="" placeholder="Your name" /></label>
          <label>Phone<input defaultValue="" placeholder="+91 9876543210" /></label>
          <label>Email<input defaultValue="" placeholder="you@example.com" /></label>
          <label className="wide">Address<input defaultValue="" placeholder="Enter your address" /></label>
          <div className="save-row">
            <button className="secondary">Cancel</button>
            <button className="primary"><Check size={16} /> Save Changes</button>
          </div>
        </div>
      </section>
      <section className="panel">
        <div className="panel-title"><h3>Notifications</h3></div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <label className="toggle-row"><input type="checkbox" defaultChecked /> Email notifications</label>
          <label className="toggle-row"><input type="checkbox" defaultChecked /> SMS / OTP alerts</label>
          <label className="toggle-row"><input type="checkbox" /> Appointment reminders</label>
          <label className="toggle-row"><input type="checkbox" defaultChecked /> System updates</label>
        </div>
      </section>
    </div>
    <section className="panel" style={{ marginTop: '16px' }}>
      <div className="panel-title"><h3>Security</h3></div>
      <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
        <button className="secondary">Change Password</button>
        <button className="secondary">Enable Two-Factor Authentication</button>
      </div>
    </section>
  </div>;
}

function NotificationsPage({ role, authUserId, demoMode, navigate }: { role: Role; authUserId: string; demoMode: boolean; navigate: (p: Page) => void }) {
  const demoData = role === 'admin' ? demoAdminNotifications : role === 'doctor' ? demoDoctorNotifications : demoNotifications;
  const [notifications, setNotifications] = useState<any[]>(demoMode ? demoData : []);
  const [loading, setLoading] = useState(!demoMode);

  useEffect(() => {
    if (demoMode) { setNotifications(demoData); setLoading(false); return; }
    if (!authUserId) return;
    setLoading(true);
    fetchNotifications(authUserId).then(({ data, error }) => {
      if (!error && data) setNotifications(data);
      setLoading(false);
    });
    const channel = supabase
      .channel('notifications-changes')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${authUserId}` }, (payload: any) => {
        setNotifications((prev) => [payload.new, ...prev]);
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'notifications', filter: `user_id=eq.${authUserId}` }, (payload: any) => {
        setNotifications((prev) => prev.map((n) => n.id === payload.new.id ? payload.new : n));
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [authUserId, demoMode, role]);

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  const handleMarkRead = async (id: string) => {
    setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, is_read: true } : n));
    if (!demoMode) await markNotificationRead(id);
  };

  const handleMarkAllRead = async () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
    if (!demoMode) await markAllNotificationsRead(authUserId);
  };

  const typeIcon = (type: string) => {
    if (type === 'appointment') return <CalendarDays size={18} />;
    if (type === 'prescription') return <ClipboardList size={18} />;
    if (type === 'payment') return <DollarSign size={18} />;
    if (type === 'approval') return <Shield size={18} />;
    return <Bell size={18} />;
  };

  const typeColor = (type: string) => {
    if (type === 'appointment') return '#4365a3';
    if (type === 'prescription') return '#0b9b55';
    if (type === 'payment') return '#e73535';
    if (type === 'approval') return '#e8870a';
    return '#687993';
  };

  if (loading) return <div className="empty-state"><Loader2 size={28} className="spin" /><p>Loading notifications...</p></div>;

  return <>
    <div className="stats-row">
      <Stat number={String(unreadCount)} label="Unread" accent={unreadCount > 0 ? 'orange' : ''} />
      <Stat number={String(notifications.length)} label="Total" />
      <Stat number={String(notifications.filter((n) => n.is_read).length)} label="Read" accent="green" />
    </div>
    {unreadCount > 0 && (
      <div style={{ marginBottom: '14px' }}>
        <button className="primary" onClick={handleMarkAllRead}><Check size={15} /> Mark all as read</button>
      </div>
    )}
    {notifications.length === 0 ? (
      <div className="empty-state"><Bell size={40} /><h3>No notifications</h3><p>You're all caught up. New notifications about appointments, prescriptions, and payments will appear here.</p></div>
    ) : (
      <div className="notification-list">
        {notifications.map((n) => (
          <div key={n.id} className={`notification-card ${n.is_read ? 'read' : 'unread'}`}>
            <div className="notification-icon" style={{ color: typeColor(n.type), background: `${typeColor(n.type)}15` }}>
              {typeIcon(n.type)}
            </div>
            <div className="notification-content">
              <div className="notification-header">
                <strong>{n.title}</strong>
                {!n.is_read && <span className="unread-dot" />}
              </div>
              <p>{n.message}</p>
              <small>{new Date(n.created_at).toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</small>
            </div>
            {!n.is_read && (
              <button className="link" onClick={() => handleMarkRead(n.id)}><Check size={14} /> Mark read</button>
            )}
          </div>
        ))}
      </div>
    )}
  </>;
}

function GenericPage({ page, role, setModal }: { page: Page; role: Role; setModal: (s: string | null) => void }) {
  if (page === 'Settings') return <SettingsPage role={role} />;
  return <div className="generic-page"><div className="empty-state"><div className="empty-icon"><Settings size={27} /></div><h3>{page} workspace</h3><p>{role === 'client' ? 'Your VetWise information will appear here when it is available.' : 'Connect this view to your AWS service to load live practice data.'}</p></div></div>;
}

function CareOrchestrationPage({ role, appointmentStates }: { role: Role; appointmentStates: AppointmentState[] }) {
  const [selectedAppt, setSelectedAppt] = useState(0);
  const [states, setStates] = useState(appointmentStates);

  const handleTransition = (from: CareState, to: CareState, action: string) => {
    setStates((prev) => prev.map((a, i) =>
      i === selectedAppt ? { ...a, currentState: to, updatedAt: new Date().toISOString() } : a,
    ));
  };

  return <div className="orchestration-layout">
    <div className="left-col">
      <div className="panel" style={{ padding: '18px' }}>
        <div className="panel-title"><h3>Appointments</h3></div>
        {states.map((a, i) => (
          <button key={a.appointmentId} className={`client-card ${selectedAppt === i ? 'selected' : ''}`} style={{ width: '100%', marginBottom: '8px' }} onClick={() => setSelectedAppt(i)}>
            <div className="pet-icon"><PawPrint size={16} /></div>
            <div className="card-main">
              <strong>{a.reason}</strong>
              <span>{a.preferredTime} · {a.appointmentType}</span>
              <span className="pid-small">{a.patientId}</span>
            </div>
            <span className={`status ${CARE_STATE_COLORS[a.currentState]}`}>{CARE_STATE_LABELS[a.currentState].toUpperCase()}</span>
          </button>
        ))}
      </div>
      <CareStateMachine appointment={states[selectedAppt]} role={role} onTransition={handleTransition} />
    </div>
    <div className="right-col">
      <AssignmentEngine
        decision={demoAssignmentDecision}
        onAssign={() => {}}
        role={role as 'admin' | 'frontdesk' | 'doctor'}
      />
      <AuditTimeline events={demoAuditEvents} />
    </div>
  </div>;
}

function ClinicalContextPage() {
  return <ClinicalContextBuilder context={demoClinicalContext} />;
}

function AuditTimelinePage({ role }: { role: Role }) {
  if (role !== 'admin' && role !== 'doctor') {
    return <div className="empty-state"><Shield size={36} /><h3>Access restricted</h3><p>Audit timeline is available to administrators and veterinarians only.</p></div>;
  }
  return <AuditTimeline events={demoAuditEvents} />;
}

function ModalRouter({ modal, setModal, role, myPets, setMyPets }: any) {
  if (modal === 'Add Pet') return <AddPetModalNew onClose={() => setModal(null)} onAdd={(pet: Record<string, unknown>) => setMyPets((prev: any) => [...prev, pet])} clientId="VW-CL-000001" />;
  if (modal === 'Book a Visit') return <BookVisitModal onClose={() => setModal(null)} myPets={myPets} />;
  if (modal === 'reject-doctor') return <RejectDoctorModal onClose={() => setModal(null)} />;
  if (modal === 'Add Product') return <AddProductModal onClose={() => setModal(null)} />;
  return <DefaultModal title={modal} onClose={() => setModal(null)} />;
}

function DefaultModal({ title, onClose }: { title: string; onClose: () => void }) {
  return <div className="modal-backdrop" onClick={onClose}><div className="modal" onClick={(e) => e.stopPropagation()}>
    <div className="modal-head"><div><p className="eyebrow">VETWISE</p><h2>{title}</h2></div><button className="icon-btn" onClick={onClose}><X size={18} /></button></div>
    <div className="form-grid"><label>Client or owner<input placeholder="Search by name" /></label><label>Patient<input placeholder="Search by pet name" /></label><label>Date<input type="date" /></label><label>Notes<textarea placeholder="Add a note (optional)" /></label></div>
    <div className="modal-actions"><button className="secondary" onClick={onClose}>Cancel</button><button className="primary" onClick={onClose}><Check size={16} /> Save</button></div>
  </div></div>;
}

function BookVisitModal({ onClose, myPets }: { onClose: () => void; myPets: any[] }) {
  const [locationMode, setLocationMode] = useState<'saved' | 'current' | 'manual'>('saved');
  const [selectedPet, setSelectedPet] = useState('');
  const [visitType, setVisitType] = useState('');
  const [preferredDate, setPreferredDate] = useState('');
  const [preferredTime, setPreferredTime] = useState('');
  const [reason, setReason] = useState('');
  const [manualAddress, setManualAddress] = useState('');
  const [manualCity, setManualCity] = useState('');
  const [manualPincode, setManualPincode] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [gpsCoords, setGpsCoords] = useState<{ lat: string; lng: string } | null>(null);

  const captureGps = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => setGpsCoords({ lat: pos.coords.latitude.toFixed(6), lng: pos.coords.longitude.toFixed(6) }),
      () => {},
      { enableHighAccuracy: true, timeout: 10000 },
    );
  };

  const handleSubmit = async () => {
    if (!selectedPet) { setError('Please select your pet.'); return; }
    if (!visitType) { setError('Please select a visit type.'); return; }
    if (!preferredDate) { setError('Please select a preferred date.'); return; }
    setError('');
    setSaving(true);

    const pet = myPets.find((p) => p.name === selectedPet);
    let visitLocation = '';
    if (locationMode === 'saved') {
      const loc = clientLocations.find((l) => l.isPrimary) ?? clientLocations[0];
      visitLocation = loc ? `${loc.addressLine}, ${loc.city}, ${loc.state} — ${loc.pincode}` : '';
    } else if (locationMode === 'current' && gpsCoords) {
      visitLocation = `GPS: ${gpsCoords.lat}, ${gpsCoords.lng}`;
    } else if (locationMode === 'manual') {
      visitLocation = `${manualAddress}, ${manualCity} — ${manualPincode}`;
    }

    const apptData = {
      patient_id: pet?.patientId ?? '',
      client_id: pet?.clientId ?? 'VW-CL-000001',
      appointment_type: visitType,
      reason,
      preferred_date: preferredDate,
      preferred_time: preferredTime,
      visit_location: visitLocation,
      status: 'Pending',
    };

    await insertAppointment(apptData);
    setSaving(false);
    onClose();
  };

  return <div className="modal-backdrop" onClick={onClose}><div className="modal" style={{ width: 'min(560px,100%)' }} onClick={(e) => e.stopPropagation()}>
    <div className="modal-head"><div><p className="eyebrow">VETWISE</p><h2>Book a Visit</h2></div><button className="icon-btn" onClick={onClose}><X size={18} /></button></div>
    <div className="form-grid">
      <label>Pet<select value={selectedPet} onChange={(e) => setSelectedPet(e.target.value)}><option value="">Select your pet</option>{myPets.map((p) => <option key={p.name} value={p.name}>{p.name}</option>)}</select></label>
      <label>Visit Type<select value={visitType} onChange={(e) => setVisitType(e.target.value)}><option value="">Select type</option><option>Home Visit</option><option>Teleconsultation</option><option>Clinic Visit</option><option>Vaccination</option><option>Emergency</option></select></label>
      <label>Preferred Date<input type="date" value={preferredDate} onChange={(e) => setPreferredDate(e.target.value)} /></label>
      <label>Preferred Time<input type="time" value={preferredTime} onChange={(e) => setPreferredTime(e.target.value)} /></label>
      <label className="wide">Reason<textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Briefly describe the reason for the visit" /></label>
    </div>
    <div className="location-section">
      <strong>Visit Location</strong>
      <div className="location-mode-tabs">
        <button className={locationMode === 'saved' ? 'active' : ''} onClick={() => setLocationMode('saved')}><MapPin size={13} /> Use Saved Location</button>
        <button className={locationMode === 'current' ? 'active' : ''} onClick={() => { setLocationMode('current'); captureGps(); }}><MapPin size={13} /> Use Current Location</button>
        <button className={locationMode === 'manual' ? 'active' : ''} onClick={() => setLocationMode('manual')}><MapPin size={13} /> Enter Different Location</button>
      </div>
      {locationMode === 'saved' && (
        <div className="location-saved-list">
          {clientLocations.map((loc) => (
            <label key={loc.id} className="location-radio">
              <input type="radio" name="saved-loc" defaultChecked={loc.isPrimary} />
              <span>{loc.label}: {loc.addressLine}, {loc.city}, {loc.state} — {loc.pincode}</span>
            </label>
          ))}
        </div>
      )}
      {locationMode === 'current' && (
        <p className="location-hint">{gpsCoords ? `GPS captured: ${gpsCoords.lat}, ${gpsCoords.lng}` : 'Capturing GPS coordinates...'}</p>
      )}
      {locationMode === 'manual' && (
        <div className="form-grid" style={{ marginTop: '10px' }}>
          <label className="wide">Address<input value={manualAddress} onChange={(e) => setManualAddress(e.target.value)} placeholder="Enter visit address" /></label>
          <label>City<input value={manualCity} onChange={(e) => setManualCity(e.target.value)} placeholder="City" /></label>
          <label>Pincode<input value={manualPincode} onChange={(e) => setManualPincode(e.target.value)} placeholder="Pincode" /></label>
        </div>
      )}
    </div>
    {error && <p className="login-error" style={{ margin: '4px 0 8px' }}>{error}</p>}
    <div className="modal-actions"><button className="secondary" onClick={onClose}>Cancel</button><button className="primary" onClick={handleSubmit} disabled={saving}><Check size={16} /> {saving ? 'Requesting...' : 'Request Visit'}</button></div>
  </div></div>;
}

function RejectDoctorModal({ onClose }: { onClose: () => void }) {
  return <div className="modal-backdrop" onClick={onClose}><div className="modal" onClick={(e) => e.stopPropagation()}>
    <div className="modal-head"><div><p className="eyebrow">VETWISE ADMIN</p><h2>Reject Doctor Application</h2></div><button className="icon-btn" onClick={onClose}><X size={18} /></button></div>
    <div className="form-grid"><label className="wide">Reason for rejection<textarea placeholder="Provide a reason for rejecting this application" /></label></div>
    <div className="modal-actions"><button className="secondary" onClick={onClose}>Cancel</button><button className="danger-btn" onClick={() => { onClose(); alert('Application rejected. Note: Backend API integration is required for persistence.'); }}><Ban size={16} /> Confirm Rejection</button></div>
  </div></div>;
}

function Login({ onSignIn }: { onSignIn: (role: Role, user?: AuthUser) => void }) {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [method, setMethod] = useState<'otp' | 'password'>('password');
  const [role, setRole] = useState<Role>('doctor');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [signupName, setSignupName] = useState('');
  const [signupPhone, setSignupPhone] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupPw, setSignupPw] = useState('');
  const [showSignupPw, setShowSignupPw] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const resetState = () => { setOtpSent(false); setOtp(['', '', '', '', '', '']); setError(''); };

  const handleOtpChange = (i: number, val: string) => {
    if (!/^\d?$/.test(val)) return;
    const next = [...otp];
    next[i] = val;
    setOtp(next);
    if (val && i < 5) {
      const el = document.getElementById(`otp-${i + 1}`);
      el?.focus();
    }
  };

  const handleOtpKey = (i: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[i] && i > 0) {
      const el = document.getElementById(`otp-${i - 1}`);
      el?.focus();
    }
  };

  const sendOtp = async () => {
    if (!identifier.trim()) { setError('Please enter your email.'); return; }
    setError('');
    setLoading(true);
    try {
      const { error: otpError } = await authSendOtp(identifier.trim());
      if (otpError) throw new Error(otpError);
      setOtpSent(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  const verifyOtp = async () => {
    const code = otp.join('');
    if (code.length !== 6) { setError('Please enter the 6-digit code.'); return; }
    setError('');
    setLoading(true);
    try {
      const { user, error: verifyError } = await authVerifyOtp(identifier.trim(), code);
      if (verifyError) throw new Error(verifyError);
      if (user) onSignIn(user.role, user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid verification code');
    } finally {
      setLoading(false);
    }
  };

  const passwordSignIn = async () => {
    if (!identifier.trim()) { setError('Please enter your email.'); return; }
    if (!password) { setError('Please enter your password.'); return; }
    setError('');
    setLoading(true);
    try {
      const { user, error: signInError } = await signInWithPassword(identifier.trim(), password);
      if (signInError) throw new Error(signInError);
      if (user) onSignIn(user.role, user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Invalid credentials');
    } finally {
      setLoading(false);
    }
  };

  const signUp = async () => {
    if (!signupName.trim()) { setError('Please enter your name.'); return; }
    if (!signupPhone.trim()) { setError('Phone number is required.'); return; }
    if (signupPhone.replace(/\D/g, '').length < 10) { setError('Please enter a valid phone number.'); return; }
    if (!signupEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signupEmail)) { setError('Please enter a valid email address.'); return; }
    if (!signupPw || signupPw.length < 8) { setError('Password must be at least 8 characters.'); return; }
    if (role !== 'client' && role !== 'doctor') { setError('Only client and doctor self-registration is allowed.'); return; }
    setError('');
    setLoading(true);
    try {
      const { user, error: signUpError } = await authSignUp({
        email: signupEmail,
        password: signupPw,
        fullName: signupName,
        phone: signupPhone,
        role,
      });
      if (signUpError) throw new Error(signUpError);
      if (user) onSignIn(user.role, user);
      else { setMode('signin'); setError('Account created. Please sign in.'); }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return <div className="login-screen">
    <div className="login-art">
      <div className="brand light"><div className="brand-mark"><Stethoscope size={18} /></div><span>VetWise</span></div>
      <div className="art-copy"><p className="eyebrow">CARE, CONNECTED</p><h1>Better care for every patient.</h1><p>One calm workspace for veterinary teams and the people who love their pets.</p></div>
      <div className="art-orbit"><PawPrint size={38} /></div>
    </div>
    <div className="login-panel">
      <div className="login-box">
        <div className="brand dark"><div className="brand-mark"><Stethoscope size={18} /></div><span>VetWise</span></div>
        {mode === 'signin' ? <>
          <h2>Welcome back</h2><p>Sign in to continue to your portal.</p>
          <div className="role-switch">{(['doctor', 'client', 'admin', 'frontdesk'] as Role[]).map((r) => <button key={r} className={role === r ? 'active' : ''} onClick={() => { setRole(r); resetState(); }}>{r === 'frontdesk' ? 'Front Desk' : r[0].toUpperCase() + r.slice(1)}</button>)}</div>
          <div className="method-toggle">
            <button className={method === 'otp' ? 'active' : ''} onClick={() => { setMethod('otp'); resetState(); }}>OTP</button>
            <button className={method === 'password' ? 'active' : ''} onClick={() => { setMethod('password'); resetState(); }}>Password</button>
          </div>
          {error && <p className="login-error">{error}</p>}
          {method === 'otp' ? <>
            <label>Email<input value={identifier} onChange={(e) => setIdentifier(e.target.value)} placeholder="you@example.com" /></label>
            {otpSent ? <>
              <label>Enter OTP<div className="otp-row">{otp.map((d, i) => <input key={i} id={`otp-${i}`} value={d} onChange={(e) => handleOtpChange(i, e.target.value)} onKeyDown={(e) => handleOtpKey(i, e)} maxLength={1} inputMode="numeric" />)}</div></label>
              <p className="otp-hint">A 6-digit code was sent to {identifier}. <button className="link" onClick={() => { resetState(); }}>Resend / change</button></p>
              <button className="primary full" onClick={verifyOtp} disabled={loading}>{loading ? <Loader2 size={16} className="spin" /> : 'Verify & Sign in'}</button>
            </> : <>
              <button className="primary full" onClick={sendOtp} disabled={loading}>{loading ? <Loader2 size={16} className="spin" /> : 'Send OTP'}</button>
            </>}
          </> : <>
            <label>Email<input value={identifier} onChange={(e) => setIdentifier(e.target.value)} placeholder="you@example.com" /></label>
            <label>Password<div className="password"><input type={showPw ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" /><button onClick={() => setShowPw(!showPw)}>{showPw ? 'Hide' : 'Show'}</button></div></label>
            <div className="login-options"><label className="check"><input type="checkbox" /> Remember me</label><button className="link">Forgot password?</button></div>
            <button className="primary full" onClick={passwordSignIn} disabled={loading}>{loading ? <Loader2 size={16} className="spin" /> : 'Sign in'}</button>
          </>}
          <p className="signup">New to VetWise? <button className="link" onClick={() => { setMode('signup'); setError(''); }}>Create an account</button></p>
          <button className="demo" onClick={() => onSignIn(role)}>Enter demo workspace <ArrowUpRight size={14} /></button>
        </> : <>
          <h2>Create your account</h2><p>Join VetWise to manage pet care in one place.</p>
          <div className="role-switch">{(['doctor', 'client'] as Role[]).map((r) => <button key={r} className={role === r ? 'active' : ''} onClick={() => setRole(r)}>{r[0].toUpperCase() + r.slice(1)}</button>)}</div>
          {error && <p className="login-error">{error}</p>}
          <label>Full Name<input value={signupName} onChange={(e) => setSignupName(e.target.value)} placeholder="Enter your name" /></label>
          <label>Phone Number <span className="req">*</span><input value={signupPhone} onChange={(e) => setSignupPhone(e.target.value)} placeholder="+91 9876543210" /></label>
          <label>Email <span className="req">*</span><input value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} placeholder="you@example.com" /></label>
          <label>Password<div className="password"><input type={showSignupPw ? 'text' : 'password'} value={signupPw} onChange={(e) => setSignupPw(e.target.value)} placeholder="At least 8 characters" /><button onClick={() => setShowSignupPw(!showSignupPw)}>{showSignupPw ? 'Hide' : 'Show'}</button></div></label>
          <button className="primary full" onClick={signUp} disabled={loading}>{loading ? <Loader2 size={16} className="spin" /> : 'Create Account'}</button>
          <p className="signup">Already have an account? <button className="link" onClick={() => { setMode('signin'); setError(''); }}>Sign in</button></p>
          <button className="demo" onClick={() => onSignIn(role)}>Enter demo workspace <ArrowUpRight size={14} /></button>
        </>}
      </div>
    </div>
  </div>;
}

export default App;
