/**
 * VetWise Supabase data access — consolidated queries for all app workflows.
 * Replaces demo-data imports with live database queries.
 */

import { supabase } from './supabase';

// ---- Clients ----

export async function fetchClients() {
  return supabase
    .from('clients')
    .select('*')
    .order('created_at', { ascending: false });
}

export async function fetchClientById(clientId: string) {
  return supabase
    .from('clients')
    .select('*')
    .eq('client_id', clientId)
    .maybeSingle();
}

export async function fetchClientsByUser(userId: string) {
  return supabase
    .from('clients')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
}

// ---- Patients ----

export async function fetchPatients() {
  return supabase
    .from('patients')
    .select('*, clients(full_name, phone, city, state)')
    .order('created_at', { ascending: false });
}

export async function fetchPatientsByClient(clientId: string) {
  return supabase
    .from('patients')
    .select('*')
    .eq('client_id', clientId)
    .order('created_at', { ascending: false });
}

export async function fetchPatientById(patientId: string) {
  return supabase
    .from('patients')
    .select('*, clients(full_name, phone, city, state, email, address, client_id)')
    .eq('patient_id', patientId)
    .maybeSingle();
}

// ---- Appointments ----

export async function fetchAppointments() {
  return supabase
    .from('appointments')
    .select('*, patients(name, species, breed), clients(full_name, phone)')
    .order('preferred_date', { ascending: true });
}

export async function fetchAppointmentsByClient(clientId: string) {
  return supabase
    .from('appointments')
    .select('*, patients(name, species, breed)')
    .eq('client_id', clientId)
    .order('preferred_date', { ascending: true });
}

// ---- Clinical Records ----

export async function fetchClinicalRecords() {
  return supabase
    .from('clinical_records')
    .select('*, patients(name, species, breed), clients(full_name)')
    .order('visit_date', { ascending: false });
}

export async function fetchClinicalRecordsByPatient(patientId: string) {
  return supabase
    .from('clinical_records')
    .select('*')
    .eq('patient_id', patientId)
    .order('visit_date', { ascending: false });
}

export async function fetchClinicalRecordsByClient(clientId: string) {
  return supabase
    .from('clinical_records')
    .select('*, patients(name, species, breed)')
    .eq('client_id', clientId)
    .order('visit_date', { ascending: false });
}

// ---- Prescriptions ----

export async function fetchPrescriptions() {
  return supabase
    .from('prescriptions')
    .select('*, patients(name, species, breed), clients(full_name)')
    .order('created_at', { ascending: false });
}

export async function fetchPrescriptionsByClient(clientId: string) {
  return supabase
    .from('prescriptions')
    .select('*, patients(name, species, breed)')
    .eq('client_id', clientId)
    .order('created_at', { ascending: false });
}

// ---- Payments ----

export async function fetchPayments() {
  return supabase
    .from('payments')
    .select('*, clients(full_name, client_id)')
    .order('created_at', { ascending: false });
}

export async function fetchPaymentsByClient(clientId: string) {
  return supabase
    .from('payments')
    .select('*')
    .eq('client_id', clientId)
    .order('created_at', { ascending: false });
}

// ---- Subscriptions ----

export async function fetchSubscriptions() {
  return supabase
    .from('subscriptions')
    .select('*, clients(full_name, client_id)')
    .order('created_at', { ascending: false });
}

export async function fetchSubscriptionPlans() {
  return supabase
    .from('subscription_plans')
    .select('*')
    .eq('is_active', true)
    .order('created_at', { ascending: true });
}

// ---- Doctors ----

export async function fetchDoctors() {
  return supabase
    .from('doctors')
    .select('*')
    .eq('verification_status', 'approved')
    .order('created_at', { ascending: false });
}

export async function fetchPendingDoctors() {
  return supabase
    .from('doctors')
    .select('*')
    .eq('verification_status', 'pending')
    .order('created_at', { ascending: false });
}

export async function fetchDoctorByProfile(profileId: string) {
  return supabase
    .from('doctors')
    .select('*')
    .eq('profile_id', profileId)
    .maybeSingle();
}

// ---- Client Locations ----

export async function fetchLocationsByClient(clientId: string) {
  return supabase
    .from('client_locations')
    .select('*')
    .eq('client_id', clientId)
    .order('is_primary', { ascending: false });
}

// ---- Breeding Records ----

export async function fetchBreedingRecords(patientId: string) {
  return supabase
    .from('breeding_records')
    .select('*')
    .eq('patient_id', patientId)
    .order('created_at', { ascending: false });
}

// ---- Audit Logs ----

export async function fetchAuditLogs(entityType?: string, entityId?: string) {
  let query = supabase
    .from('audit_logs')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(100);
  if (entityType) query = query.eq('entity_type', entityType);
  if (entityId) query = query.eq('entity_id', entityId);
  return query;
}

// ---- Mutations ----

export async function insertClient(body: Record<string, unknown>) {
  return supabase.from('clients').insert(body).select().single();
}

export async function updateClient(clientId: string, body: Record<string, unknown>) {
  return supabase
    .from('clients')
    .update({ ...body, updated_at: new Date().toISOString() })
    .eq('client_id', clientId)
    .select()
    .maybeSingle();
}

export async function insertPatient(body: Record<string, unknown>) {
  return supabase.from('patients').insert(body).select().single();
}

export async function updatePatient(patientId: string, body: Record<string, unknown>) {
  return supabase
    .from('patients')
    .update({ ...body, updated_at: new Date().toISOString() })
    .eq('patient_id', patientId)
    .select()
    .maybeSingle();
}

export async function insertAppointment(body: Record<string, unknown>) {
  return supabase.from('appointments').insert(body).select().single();
}

export async function insertClinicalRecord(body: Record<string, unknown>) {
  return supabase.from('clinical_records').insert(body).select().single();
}

export async function insertPrescription(body: Record<string, unknown>) {
  return supabase.from('prescriptions').insert(body).select().single();
}

export async function approveDoctor(doctorId: string, adminId: string) {
  return supabase
    .from('doctors')
    .update({
      verification_status: 'approved',
      verified_at: new Date().toISOString(),
      verified_by: adminId,
      updated_at: new Date().toISOString(),
    })
    .eq('id', doctorId)
    .select()
    .maybeSingle();
}

export async function rejectDoctor(doctorId: string, reason: string) {
  return supabase
    .from('doctors')
    .update({
      verification_status: 'rejected',
      rejection_reason: reason,
      updated_at: new Date().toISOString(),
    })
    .eq('id', doctorId)
    .select()
    .maybeSingle();
}

export async function insertDoctor(body: Record<string, unknown>) {
  return supabase.from('doctors').insert(body).select().single();
}

// ---- Notifications ----

export async function fetchNotifications(userId: string) {
  return supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
}

export async function markNotificationRead(id: string) {
  return supabase
    .from('notifications')
    .update({ is_read: true })
    .eq('id', id);
}

export async function markAllNotificationsRead(userId: string) {
  return supabase
    .from('notifications')
    .update({ is_read: true })
    .eq('user_id', userId)
    .eq('is_read', false);
}

export async function insertNotification(body: Record<string, unknown>) {
  return supabase.from('notifications').insert(body).select().single();
}
