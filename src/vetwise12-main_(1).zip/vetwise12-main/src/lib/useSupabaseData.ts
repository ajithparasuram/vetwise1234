/**
 * useSupabaseData — fetches data from Supabase with proper loading/error states.
 * Returns null data (not demo data) when queries fail or return empty.
 */

import { useCallback, useEffect, useState } from 'react';
import { supabase, isSupabaseConfigured } from './supabase';

interface DataState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

export function useSupabaseQuery<T>(
  key: string,
  fetcher: () => Promise<{ data: T | null; error: { message: string } | null }>,
  deps: unknown[] = [],
): DataState<T> & { refetch: () => void } {
  const [state, setState] = useState<DataState<T>>({
    data: null,
    loading: true,
    error: null,
  });

  const fetchData = useCallback(async () => {
    if (!isSupabaseConfigured()) {
      setState({ data: null, loading: false, error: 'Supabase is not configured.' });
      return;
    }
    setState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const result = await fetcher();
      if (result.error) {
        setState({ data: null, loading: false, error: result.error.message });
      } else {
        setState({ data: result.data, loading: false, error: null });
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load data';
      setState({ data: null, loading: false, error: message });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, ...deps]);

  useEffect(() => { fetchData(); }, [fetchData]);

  return { ...state, refetch: fetchData };
}

export function useSupabaseMutation() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mutate = useCallback(async <T,>(
    fn: () => Promise<{ data: T | null; error: { message: string } | null }>,
  ): Promise<T | null> => {
    setLoading(true);
    setError(null);
    try {
      const result = await fn();
      if (result.error) {
        setError(result.error.message);
        setLoading(false);
        return null;
      }
      setLoading(false);
      return result.data;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Operation failed';
      setError(message);
      setLoading(false);
      return null;
    }
  }, []);

  return { mutate, loading, error };
}

export { supabase };
