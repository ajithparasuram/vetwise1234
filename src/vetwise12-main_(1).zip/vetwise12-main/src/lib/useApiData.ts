/**
 * useApiData — fetches data from the backend API with graceful fallback
 * to demo data when the backend is not deployed yet.
 *
 * Pattern:
 *   const { data, loading, error, refetch } = useApiData('clients', () => api.getClients(), demoClients);
 *
 * When VITE_API_BASE_URL is not set, immediately returns demo data.
 * When the API call fails, falls back to demo data and logs a warning.
 */

import { useCallback, useEffect, useState } from 'react';
import { ApiUnavailableError, isApiAvailable } from './api';

interface ApiDataState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  usingFallback: boolean;
}

export function useApiData<T>(
  key: string,
  fetcher: () => Promise<T>,
  fallback: T,
): ApiDataState<T> & { refetch: () => void } {
  const [state, setState] = useState<ApiDataState<T>>({
    data: isApiAvailable() ? null : fallback,
    loading: isApiAvailable(),
    error: null,
    usingFallback: !isApiAvailable(),
  });

  const fetchData = useCallback(async () => {
    if (!isApiAvailable()) {
      setState({ data: fallback, loading: false, error: null, usingFallback: true });
      return;
    }

    setState((prev) => ({ ...prev, loading: true, error: null }));
    try {
      const result = await fetcher();
      setState({ data: result, loading: false, error: null, usingFallback: false });
    } catch (err) {
      if (err instanceof ApiUnavailableError) {
        setState({ data: fallback, loading: false, error: null, usingFallback: true });
        return;
      }
      const message = err instanceof Error ? err.message : 'Failed to load data';
      console.warn(`[VetWise] API call failed for "${key}", using demo data:`, message);
      setState({ data: fallback, loading: false, error: message, usingFallback: true });
    }
  }, [key, fetcher, fallback]);

  useEffect(() => { fetchData(); }, [fetchData]);

  return { ...state, refetch: fetchData };
}

export function useApiMutation() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mutate = useCallback(async <T>(fn: () => Promise<T>): Promise<T | null> => {
    if (!isApiAvailable()) {
      setError('Backend API is not configured. Changes will not be persisted.');
      return null;
    }
    setLoading(true);
    setError(null);
    try {
      const result = await fn();
      setLoading(false);
      return result;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Operation failed';
      setError(message);
      setLoading(false);
      return null;
    }
  }, []);

  return { mutate, loading, error };
}
