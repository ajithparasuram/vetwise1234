/**
 * VetWise Supabase Auth Layer
 *
 * Replaces the AWS Cognito auth flow with Supabase Auth.
 * Provides: signUp, signInWithPassword, signInWithOtp, verifyOtp,
 * signOut, getSession, getCurrentUser, and onAuthStateChange.
 *
 * Role is stored in raw_app_meta_data (user-immutable) and mirrored
 * in the profiles table. The frontend reads role from profiles, never
 * from user-selected state.
 */

import { supabase, isSupabaseConfigured } from './supabase';

export type Role = 'client' | 'doctor' | 'admin' | 'frontdesk';

export interface AuthUser {
  id: string;
  email: string;
  role: Role;
  fullName: string;
  phone: string;
  approvalStatus: string;
  hospitalId: string | null;
}

export interface AuthSession {
  userId: string;
  email: string;
}

export async function signUp(params: {
  email: string;
  password: string;
  fullName: string;
  phone: string;
  role: Role;
}): Promise<{ user: AuthUser | null; error: string | null }> {
  if (!isSupabaseConfigured()) {
    return { user: null, error: 'Supabase is not configured.' };
  }

  const { data, error } = await supabase.auth.signUp({
    email: params.email,
    password: params.password,
    options: {
      data: {
        full_name: params.fullName,
        phone: params.phone,
        role: params.role,
      },
    },
  });

  if (error) return { user: null, error: error.message };
  if (!data.user) return { user: null, error: 'Sign-up failed. Please try again.' };

  const user = await fetchUserProfile(data.user.id);
  return { user, error: null };
}

export async function signInWithPassword(
  email: string,
  password: string,
): Promise<{ user: AuthUser | null; error: string | null }> {
  if (!isSupabaseConfigured()) {
    return { user: null, error: 'Supabase is not configured.' };
  }

  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { user: null, error: error.message };
  if (!data.user) return { user: null, error: 'Sign-in failed.' };

  const user = await fetchUserProfile(data.user.id);
  if (!user) return { user: null, error: 'Profile not found. Please contact support.' };

  if (user.approvalStatus === 'pending') {
    return { user: null, error: 'Your account is pending admin approval. You will be notified once approved.' };
  }
  if (user.approvalStatus === 'rejected') {
    return { user: null, error: 'Your account application was rejected. Please contact support.' };
  }
  if (user.approvalStatus === 'suspended') {
    return { user: null, error: 'Your account has been suspended. Please contact support.' };
  }

  return { user, error: null };
}

export async function sendOtp(
  email: string,
): Promise<{ error: string | null }> {
  if (!isSupabaseConfigured()) {
    return { error: 'Supabase is not configured.' };
  }

  const { error } = await supabase.auth.signInWithOtp({
    email,
    options: { shouldCreateUser: false },
  });
  return { error: error?.message ?? null };
}

export async function verifyOtp(
  email: string,
  code: string,
): Promise<{ user: AuthUser | null; error: string | null }> {
  if (!isSupabaseConfigured()) {
    return { user: null, error: 'Supabase is not configured.' };
  }

  const { data, error } = await supabase.auth.verifyOtp({
    email,
    token: code,
    type: 'email',
  });
  if (error) return { user: null, error: error.message };
  if (!data.user) return { user: null, error: 'Verification failed.' };

  const user = await fetchUserProfile(data.user.id);
  if (!user) return { user: null, error: 'Profile not found.' };

  if (user.approvalStatus === 'pending') {
    return { user: null, error: 'Your account is pending admin approval.' };
  }
  if (user.approvalStatus === 'rejected') {
    return { user: null, error: 'Your account application was rejected.' };
  }
  if (user.approvalStatus === 'suspended') {
    return { user: null, error: 'Your account has been suspended.' };
  }

  return { user, error: null };
}

export async function signOut(): Promise<void> {
  if (!isSupabaseConfigured()) return;
  await supabase.auth.signOut();
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  if (!isSupabaseConfigured()) return null;

  const { data: sessionData } = await supabase.auth.getSession();
  if (!sessionData.session?.user) return null;

  return fetchUserProfile(sessionData.session.user.id);
}

async function fetchUserProfile(userId: string): Promise<AuthUser | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, email, role, full_name, phone, approval_status, hospital_id')
    .eq('id', userId)
    .maybeSingle();

  if (error || !data) return null;

  return {
    id: data.id,
    email: data.email ?? '',
    role: (data.role as Role) ?? 'client',
    fullName: data.full_name ?? '',
    phone: data.phone ?? '',
    approvalStatus: data.approval_status ?? 'approved',
    hospitalId: data.hospital_id ?? null,
  };
}

export function onAuthStateChange(
  callback: (user: AuthUser | null) => void,
): () => void {
  if (!isSupabaseConfigured()) return () => {};

  const { data } = supabase.auth.onAuthStateChange((_event, session) => {
    (async () => {
      if (!session?.user) {
        callback(null);
        return;
      }
      const user = await fetchUserProfile(session.user.id);
      callback(user);
    })();
  });

  return () => data.subscription.unsubscribe();
}
