/**
 * VetWise Supabase data access layer.
 *
 * Provides typed functions for querying clients, patients, locations,
 * media, breeding records, and audit logs directly from Supabase.
 * Falls back gracefully when Supabase is not configured.
 */

import { supabase, isSupabaseConfigured } from './supabase';

// ---- Types ----

export interface ClientRecord {
  id: string;
  client_id: string;
  user_id: string | null;
  full_name: string;
  phone: string;
  email: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  pincode: string | null;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface PatientRecord {
  id: string;
  patient_id: string;
  client_id: string;
  name: string;
  species: string;
  custom_species: string | null;
  breed: string | null;
  sex: string | null;
  date_of_birth: string | null;
  estimated_age: string | null;
  weight: string | null;
  color: string | null;
  markings: string | null;
  microchip_number: string | null;
  identification_details: string | null;
  notes: string | null;
  allergies: string | null;
  existing_conditions: string | null;
  medical_history: string | null;
  vaccination_info: string | null;
  medications: string | null;
  special_requirements: string | null;
  breeding_eligible: boolean;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface ClientLocation {
  id: string;
  client_id: string;
  label: string;
  latitude: number | null;
  longitude: number | null;
  location_accuracy: number | null;
  address_line: string | null;
  locality: string | null;
  city: string | null;
  district: string | null;
  state: string | null;
  pincode: string | null;
  is_primary: boolean;
  created_at: string;
}

export interface PatientMediaRecord {
  id: string;
  patient_id: string;
  media_type: 'FACE' | 'BODY' | 'ADDITIONAL' | 'CLINICAL' | 'VIDEO';
  storage_key: string;
  content_type: string | null;
  file_size: number | null;
  caption: string | null;
  uploader_id: string | null;
  uploaded_at: string;
}

export interface BreedingRecord {
  id: string;
  patient_id: string;
  partner_patient_id: string | null;
  partner_details: string | null;
  breeding_date: string | null;
  expected_date: string | null;
  number_of_offspring: number | null;
  breeding_outcome: string | null;
  veterinary_observations: string | null;
  notes: string | null;
  status: string;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface AuditLogRecord {
  id: string;
  actor_id: string | null;
  action_type: string;
  entity_type: string;
  entity_id: string | null;
  details: Record<string, unknown> | null;
  created_at: string;
}

// ---- Data Access Functions ----

export const db = {
  // ---- Clients ----
  async getClients(): Promise<ClientRecord[] | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) { console.warn('[VetWise] getClients:', error.message); return null; }
    return data as ClientRecord[];
  },

  async getClientById(clientId: string): Promise<ClientRecord | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .eq('client_id', clientId)
      .maybeSingle();
    if (error) { console.warn('[VetWise] getClientById:', error.message); return null; }
    return data as ClientRecord | null;
  },

  async searchClients(query: string): Promise<ClientRecord[] | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .or(`client_id.ilike.%${query}%,full_name.ilike.%${query}%,phone.ilike.%${query}%`)
      .order('created_at', { ascending: false })
      .limit(50);
    if (error) { console.warn('[VetWise] searchClients:', error.message); return null; }
    return data as ClientRecord[];
  },

  async createClient(body: Partial<ClientRecord>): Promise<ClientRecord | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('clients')
      .insert(body)
      .select()
      .single();
    if (error) { console.warn('[VetWise] createClient:', error.message); return null; }
    return data as ClientRecord;
  },

  // ---- Patients ----
  async getPatients(): Promise<PatientRecord[] | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('patients')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) { console.warn('[VetWise] getPatients:', error.message); return null; }
    return data as PatientRecord[];
  },

  async getPatientsByClient(clientId: string): Promise<PatientRecord[] | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('patients')
      .select('*')
      .eq('client_id', clientId)
      .order('created_at', { ascending: false });
    if (error) { console.warn('[VetWise] getPatientsByClient:', error.message); return null; }
    return data as PatientRecord[];
  },

  async getPatientById(patientId: string): Promise<PatientRecord | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('patients')
      .select('*')
      .eq('patient_id', patientId)
      .maybeSingle();
    if (error) { console.warn('[VetWise] getPatientById:', error.message); return null; }
    return data as PatientRecord | null;
  },

  async searchPatients(query: string): Promise<PatientRecord[] | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('patients')
      .select('*, clients(full_name, phone, city, state)')
      .or(`patient_id.ilike.%${query}%,name.ilike.%${query}%,breed.ilike.%${query}%,species.ilike.%${query}%`)
      .order('created_at', { ascending: false })
      .limit(50);
    if (error) { console.warn('[VetWise] searchPatients:', error.message); return null; }
    return data as unknown as PatientRecord[];
  },

  async createPatient(body: Partial<PatientRecord>): Promise<PatientRecord | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('patients')
      .insert(body)
      .select()
      .single();
    if (error) { console.warn('[VetWise] createPatient:', error.message); return null; }
    return data as PatientRecord;
  },

  async updatePatient(patientId: string, body: Partial<PatientRecord>): Promise<PatientRecord | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('patients')
      .update({ ...body, updated_at: new Date().toISOString() })
      .eq('patient_id', patientId)
      .select()
      .maybeSingle();
    if (error) { console.warn('[VetWise] updatePatient:', error.message); return null; }
    return data as PatientRecord | null;
  },

  // ---- Client Locations ----
  async getLocations(clientId: string): Promise<ClientLocation[] | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('client_locations')
      .select('*')
      .eq('client_id', clientId)
      .order('is_primary', { ascending: false });
    if (error) { console.warn('[VetWise] getLocations:', error.message); return null; }
    return data as ClientLocation[];
  },

  async createLocation(body: Partial<ClientLocation>): Promise<ClientLocation | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('client_locations')
      .insert(body)
      .select()
      .single();
    if (error) { console.warn('[VetWise] createLocation:', error.message); return null; }
    return data as ClientLocation;
  },

  async deleteLocation(id: string): Promise<boolean> {
    if (!isSupabaseConfigured()) return false;
    const { error } = await supabase.from('client_locations').delete().eq('id', id);
    if (error) { console.warn('[VetWise] deleteLocation:', error.message); return false; }
    return true;
  },

  // ---- Patient Media ----
  async getMedia(patientId: string): Promise<PatientMediaRecord[] | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('patient_media')
      .select('*')
      .eq('patient_id', patientId)
      .order('uploaded_at', { ascending: false });
    if (error) { console.warn('[VetWise] getMedia:', error.message); return null; }
    return data as PatientMediaRecord[];
  },

  async createMedia(body: Partial<PatientMediaRecord>): Promise<PatientMediaRecord | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('patient_media')
      .insert(body)
      .select()
      .single();
    if (error) { console.warn('[VetWise] createMedia:', error.message); return null; }
    return data as PatientMediaRecord;
  },

  async deleteMedia(id: string): Promise<boolean> {
    if (!isSupabaseConfigured()) return false;
    const { error } = await supabase.from('patient_media').delete().eq('id', id);
    if (error) { console.warn('[VetWise] deleteMedia:', error.message); return false; }
    return true;
  },

  // ---- Breeding Records ----
  async getBreedingRecords(patientId: string): Promise<BreedingRecord[] | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('breeding_records')
      .select('*')
      .eq('patient_id', patientId)
      .order('created_at', { ascending: false });
    if (error) { console.warn('[VetWise] getBreedingRecords:', error.message); return null; }
    return data as BreedingRecord[];
  },

  async createBreedingRecord(body: Partial<BreedingRecord>): Promise<BreedingRecord | null> {
    if (!isSupabaseConfigured()) return null;
    const { data, error } = await supabase
      .from('breeding_records')
      .insert(body)
      .select()
      .single();
    if (error) { console.warn('[VetWise] createBreedingRecord:', error.message); return null; }
    return data as BreedingRecord;
  },

  // ---- Audit Logs ----
  async logAction(actionType: string, entityType: string, entityId: string, details?: Record<string, unknown>): Promise<void> {
    if (!isSupabaseConfigured()) return;
    await supabase.from('audit_logs').insert({
      action_type: actionType,
      entity_type: entityType,
      entity_id: entityId,
      details: details ?? null,
    });
  },

  async getAuditLogs(entityType?: string, entityId?: string): Promise<AuditLogRecord[] | null> {
    if (!isSupabaseConfigured()) return null;
    let query = supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(100);
    if (entityType) query = query.eq('entity_type', entityType);
    if (entityId) query = query.eq('entity_id', entityId);
    const { data, error } = await query;
    if (error) { console.warn('[VetWise] getAuditLogs:', error.message); return null; }
    return data as AuditLogRecord[];
  },

  // ---- Storage ----
  async uploadPatientMedia(patientId: string, fileType: string, file: File): Promise<string | null> {
    if (!isSupabaseConfigured()) return null;
    const ext = file.name.split('.').pop();
    const fileName = `${patientId}/${fileType}/${Date.now()}.${ext}`;
    const { error } = await supabase.storage
      .from('patient-media')
      .upload(fileName, file, { contentType: file.type });
    if (error) { console.warn('[VetWise] uploadPatientMedia:', error.message); return null; }
    return fileName;
  },

  async getMediaUrl(storageKey: string): Promise<string | null> {
    if (!isSupabaseConfigured()) return null;
    const { data } = supabase.storage.from('patient-media').getPublicUrl(storageKey);
    return data.publicUrl;
  },
};
