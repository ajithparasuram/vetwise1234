# Changes in this revision

Files changed: `src/App.tsx`, `src/components/AddPetModal.tsx`, `src/components/PatientSearch.tsx`. Nothing deleted.

- Client "My Pets" now loads from `GET /patients` (the backend scopes it by the signed-in user's sub). Previously it depended on a `/clients` record existing first, so pets could silently never appear. Added loading, error + Retry and empty states, and it refreshes after a create.
- Removed hardcoded "Welcome back, Priya", "5 registered clients" and "8 patients across 5 clients" subtitles.
- Client Profile "Save Changes" now calls `PUT /clients/{sub}` (allowed by the handler for self), shows success only on a 2xx, shows the server error otherwise. Demo mode stays local and says so. Removed hardcoded "P" avatar and "Mumbai, Maharashtra · Joined Mar 2025".
- Admin Payments "Pending" is now computed from payment status instead of a literal 0.
- Notification bell badge "1" only shows in demo mode.
- Fixed leftover snake_case fields from the Supabase era (`patient_id`, `client_id`, `full_name`) in AddPetModal and PatientSearch; they now use the AWS fields (`petId`, `ownerId`, `name`).

Not changed / known: 5 remaining TypeScript strictness errors (BreedingPanel, GpsLocationPicker, OfflineSyncPanel) that do not stop `vite build`. Admin Subscriptions "MRR" still parses price strings. Module-level demo constants in App.tsx are still used for demo mode only.


## Revision 2 (three blocking fixes)

Files changed: `src/App.tsx`, `src/components/AddPetModal.tsx`, `src/components/PatientSearch.tsx`.

1. **Add pet no longer fakes success.** It now saves through `insertPatient`, and on failure it stays open, keeps the form and shows the server error. It calls `onAdd` and closes only after the server returns the created record, and the list is then refreshed from the server. Only fields the bundled patients handler persists are sent (`name`, `species`, `sex`, `breed`, `color`, `age`, `weight`). For species "Other", the custom type is sent as `species`. Fields the handler does not store (date of birth, microchip, medical, breeding, photos, video) are no longer sent, and the form says so. In demo mode nothing is sent.
2. **Client profile identity.** The profile page now looks up the account's real owner record (match on `ownerId` or `cognitoSub`) and uses that record's own `ownerId` for `PUT /clients/{ownerId}`. It no longer sends the sign-in sub. If no owner record is found, Save is disabled with a clear message. Server errors are shown as returned.
3. **Patient Search.** Failed requests show an error with Retry and never fall back to demo records. A successful empty response shows "No results found". Demo records appear only when demo mode was explicitly chosen, with a DEMO — NOT SAVED TO SERVER label. Also fixed: searching with a query returned raw pet records mislabelled as search results.

### Unresolved backend contract issue (not changed, needs your decision)
In the bundled Lambda source, signup creates the owner with a generated `ownerId` plus a separate `cognitoSub`, but `GET /clients` (client role) and `PUT /clients/{id}` look the owner up by `ownerId == sub`, and `GET/POST /patients` use `ownerId = sub`. For a normal client these cannot all be true at once, so profile saving will likely fail until the backend identity model is reconciled. The deployed API may differ from this source; verify before changing either side.
