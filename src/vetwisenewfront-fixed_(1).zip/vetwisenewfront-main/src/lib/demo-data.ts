/**
 * Demo/fallback data used when the backend is not deployed.
 * This keeps the app fully functional for preview and development.
 * Now includes Client IDs, Patient IDs, species, breeding, media, and locations.
 */

export const SPECIES_LIST = [
  'Dog', 'Cat', 'Cattle', 'Horse', 'Goat', 'Sheep', 'Rabbit', 'Poultry',
  'Pig', 'Buffalo', 'Elephant', 'Camel', 'Donkey', 'Other',
];

export const BREED_SUGGESTIONS = [
  'Labrador Retriever', 'German Shepherd', 'Golden Retriever', 'Poodle', 'Beagle',
  'Rottweiler', 'Doberman', 'Pug', 'Chihuahua', 'Great Dane', 'Siberian Husky',
  'Persian', 'Siamese', 'Maine Coon', 'Bengal', 'British Shorthair', 'Ragdoll',
  'Gir', 'Sahiwal', 'Holstein Friesian', 'Jersey', 'Tharparkar',
  'Murrah Buffalo', 'Mehsana Buffalo',
  'Marwari', 'Kathiawari', 'Arabian Horse', 'Thoroughbred',
  'Beetal', 'Jamunapari', 'Boer', 'Sirohi',
  'Angora', 'Rex', 'Dutch', 'Mini Lop',
  'Leghorn', 'Rhode Island Red', 'Kadaknath',
  'Large White', 'Duroc', 'Landrace',
  'Indian Elephant', 'African Elephant',
  'Dromedary', 'Bactrian',
  'Poisson',
];

export const demoClients = [
  { ownerId: 'demo_1', clientId: 'VW-CL-000001', name: 'Priya Sharma', city: 'Mumbai, Maharashtra', pets: 'Bruno · Whiskers', last: '15 Sept 2026', initials: 'P', email: 'priya@demo.com', phone: '+91 9876543210', address: '12 MG Road, Bandra West, Mumbai, Maharashtra — 400050', status: 'Active', joined: '18 Mar 2025' },
  { ownerId: 'demo_2', clientId: 'VW-CL-000002', name: 'Ramesh Patel', city: 'New Delhi, Delhi', pets: 'Nandi · Kali', last: '—', initials: 'R', email: 'ramesh@demo.com', phone: '+91 9812345678', address: '45 Ring Road, New Delhi, Delhi — 110001', status: 'Active', joined: '22 Apr 2025' },
  { ownerId: 'demo_3', clientId: 'VW-CL-000003', name: 'Suresh Kumar', city: 'Bengaluru, Karnataka', pets: 'Raja · Max', last: '—', initials: 'S', email: 'suresh@demo.com', phone: '+91 9800011122', address: '8 Brigade Road, Bengaluru, Karnataka — 560001', status: 'Active', joined: '1 Jul 2025' },
  { ownerId: 'demo_4', clientId: 'VW-CL-000004', name: 'Anita Desai', city: 'Pune, Maharashtra', pets: 'Chotu', last: '—', initials: 'A', email: 'anita@demo.com', phone: '+91 9844556677', address: '23 FC Road, Pune, Maharashtra — 411005', status: 'Active', joined: '15 Aug 2025' },
  { ownerId: 'demo_5', clientId: 'VW-CL-000005', name: 'Vikram Singh', city: 'Jaipur, Rajasthan', pets: 'Snowy', last: '—', initials: 'V', email: 'vikram@demo.com', phone: '+91 9899887766', address: '17 MI Road, Jaipur, Rajasthan — 302001', status: 'Pending', joined: '15 Sept 2026' },
];

export const demoPatients = [
  ['Bruno', 'Dog', 'Labrador Retriever · Golden', '3y 2m · 28.5 kg', 'Priya Sharma', '2 visits', 'VW-CL-000001-P01'],
  ['Whiskers', 'Cat', 'Persian · White & Grey', '2y 8m · 4.2 kg', 'Priya Sharma', '1 visit', 'VW-CL-000001-P02'],
  ['Nandi', 'Cattle', 'Gir · Brown & White', '5y 0m · 380 kg', 'Ramesh Patel', '0 visits', 'VW-CL-000002-P01'],
  ['Kali', 'Cattle', 'Murrah Buffalo · Black', '4y 6m · 450 kg', 'Ramesh Patel', '0 visits', 'VW-CL-000002-P02'],
  ['Raja', 'Horse', 'Marwari · Bay (Brown with black mane)', '7y 3m · 480 kg', 'Suresh Kumar', '0 visits', 'VW-CL-000003-P01'],
  ['Chotu', 'Goat', 'Beetal · Black & White', '1y 4m · 18 kg', 'Anita Desai', '0 visits', 'VW-CL-000004-P01'],
  ['Snowy', 'Rabbit', 'Angora · White', '10m · 2.1 kg', 'Vikram Singh', '0 visits', 'VW-CL-000005-P01'],
];

export const demoMyPets = [
  {
    patientId: 'VW-CL-000001-P01',
    clientId: 'VW-CL-000001',
    name: 'Bruno', species: 'Dog', breed: 'Labrador Retriever', color: 'Golden',
    sex: 'Male', age: '3y 2m', weight: '28.5 kg', visits: 2, lastVisit: '15 Sept 2026',
    dateOfBirth: '2023-07-15', markings: 'White patch on chest', microchip: '985112003456789',
    allergies: 'None known', existingConditions: 'None', medicalHistory: 'Routine vaccinations up to date',
    vaccinationInfo: 'Rabies (Jan 2026), DHPP (Jan 2026)', medications: 'Multivitamin supplement',
    specialRequirements: 'Sensitive stomach — avoid dairy',
    breedingEligible: true, facePhoto: null, bodyPhoto: null, additionalPhotos: [],
  },
  {
    patientId: 'VW-CL-000001-P02',
    clientId: 'VW-CL-000001',
    name: 'Whiskers', species: 'Cat', breed: 'Persian', color: 'White & Grey',
    sex: 'Female', age: '2y 8m', weight: '4.2 kg', visits: 1, lastVisit: '2 Sept 2026',
    dateOfBirth: '2024-01-20', markings: 'Grey tips on ears and tail', microchip: '',
    allergies: 'Possible pollen allergy', existingConditions: 'Bacterial dermatitis (resolved)',
    medicalHistory: 'Skin infection treated Sept 2026', vaccinationInfo: 'FVRCP (Mar 2026)',
    medications: 'Amoxicillin 250mg (completed)',
    specialRequirements: 'Indoor cat — sensitive skin',
    breedingEligible: false, facePhoto: null, bodyPhoto: null, additionalPhotos: [],
  },
];

export const demoBreedingRecords = [
  {
    id: 'demo_br1',
    patientId: 'VW-CL-000001-P01',
    partnerPatientId: null,
    partnerDetails: 'Bella — Golden Retriever (external, unregistered)',
    breedingDate: '2026-08-15',
    expectedDate: '2026-10-18',
    numberOfOffspring: null,
    breedingOutcome: null,
    veterinaryObservations: 'Healthy mating confirmed. Recommended prenatal check-up at 30 days.',
    notes: 'First breeding for Bruno. Owner monitoring appetite and activity.',
    status: 'Active',
  },
];

export const demoClientLocations = [
  {
    id: 'demo_loc1',
    clientId: 'VW-CL-000001',
    label: 'Home',
    latitude: 19.0596,
    longitude: 72.8295,
    locationAccuracy: 15,
    addressLine: '12 MG Road, Bandra West',
    locality: 'Bandra West',
    city: 'Mumbai',
    district: 'Mumbai Suburban',
    state: 'Maharashtra',
    pincode: '400050',
    isPrimary: true,
  },
];

export const demoPaidPayments = [
  { service: 'Gold Plan — Annual Subscription', amount: '₹12,000', date: '1 Jan 2026', method: 'UPI', status: 'PAID' },
  { service: 'Home Visit — Bruno (Vaccination)', amount: '₹800', date: '15 Sept 2026', method: 'Card', status: 'PAID' },
  { service: 'Home Visit — Whiskers (Skin Infection)', amount: '₹1,200', date: '2 Sept 2026', method: 'UPI', status: 'PAID' },
];

export const demoUpcomingPayments = [
  { service: 'Home Visit — Bruno (Annual Check-up)', amount: '₹1,000', due: '5 Oct 2026', status: 'UPCOMING' },
  { service: 'Gold Plan Renewal — Annual', amount: '₹12,000', due: '1 Jan 2027', status: 'UPCOMING' },
];

export const demoLivePayments = [
  { service: 'Home Visit — Whiskers (Follow-up Consultation)', amount: '₹800', status: 'LIVE' },
];

export const demoAllPayments = [
  { client: 'Priya Sharma', clientId: 'VW-CL-000001', service: 'Gold Plan — Annual Subscription', amount: '₹12,000', date: '1 Jan 2026', method: 'UPI', status: 'PAID' },
  { client: 'Priya Sharma', clientId: 'VW-CL-000001', service: 'Home Visit — Bruno (Vaccination)', amount: '₹800', date: '15 Sept 2026', method: 'Card', status: 'PAID' },
  { client: 'Priya Sharma', clientId: 'VW-CL-000001', service: 'Home Visit — Whiskers (Skin Infection)', amount: '₹1,200', date: '2 Sept 2026', method: 'UPI', status: 'PAID' },
  { client: 'Ramesh Patel', clientId: 'VW-CL-000002', service: 'Silver Plan — 6 Month Subscription', amount: '₹6,500', date: '1 Apr 2026', method: 'Net Banking', status: 'PAID' },
  { client: 'Suresh Kumar', clientId: 'VW-CL-000003', service: 'Platinum Plan — Annual Subscription', amount: '₹22,000', date: '1 Jul 2026', method: 'UPI', status: 'PAID' },
];

export const demoAllSubs = [
  { client: 'Priya Sharma', clientId: 'VW-CL-000001', plan: 'Gold Plan — Annual', price: '₹12,000', start: '1 Jan 2026', status: 'Active' },
  { client: 'Ramesh Patel', clientId: 'VW-CL-000002', plan: 'Silver Plan — 6 Month', price: '₹6,500', start: '1 Apr 2026', status: 'Active' },
  { client: 'Suresh Kumar', clientId: 'VW-CL-000003', plan: 'Platinum Plan — Annual', price: '₹22,000', start: '1 Jul 2026', status: 'Active' },
  { client: 'Anita Desai', clientId: 'VW-CL-000004', plan: 'Bronze Plan — Monthly', price: '₹500', start: '1 Sept 2026', status: 'Pending' },
];

export const demoPlans = [
  { name: 'Bronze', price: '₹500', period: '/month', benefits: ['1 home visit per month', 'Teleconsultation (2 calls)', 'Digital prescriptions', 'Vaccination reminders'], current: false },
  { name: 'Gold', price: '₹12,000', period: '/year', benefits: ['Unlimited home visits', '24/7 teleconsultation', 'Digital prescriptions', 'Vaccination reminders', 'Priority scheduling'], current: true },
  { name: 'Platinum', price: '₹22,000', period: '/year', benefits: ['Everything in Gold', 'Emergency vet visits', 'Surgery coverage', 'Lab tests included', 'Dedicated vet manager'], current: false },
];

export const demoPendingDoctors = [
  { doctorId: 'demo_pd1', name: 'Dr. Meera Iyer', email: 'meera@vetwise.com', phone: '+91 9811122334', specialty: 'Small Animal Medicine', license: 'KAR-VC-2019-4521', experience: '8 years', clinic: 'Bengaluru Pet Clinic', applied: '25 Sept 2026' },
  { doctorId: 'demo_pd2', name: 'Dr. Rohan Gupta', email: 'rohan@vetwise.com', phone: '+91 9822334455', specialty: 'Equine Surgery', license: 'RAJ-VC-2020-8832', experience: '6 years', clinic: 'Jaipur Equine Hospital', applied: '24 Sept 2026' },
];

export const demoActiveDoctors = [
  { doctorId: 'demo_ad1', name: 'Dr. Anita Rao', email: 'anita@vetwise.com', phone: '+91 9800112233', specialty: 'General Practice', license: 'MAH-VC-2018-1234', experience: '10 years', joined: '12 Jan 2025' },
  { doctorId: 'demo_ad2', name: 'Dr. Vikram Sethi', email: 'vikram@vetwise.com', phone: '+91 9800445566', specialty: 'Surgery', license: 'DEL-VC-2019-5678', experience: '7 years', joined: '3 Mar 2025' },
];

export const demoAppointments = [
  { appointmentId: 'demo_a1', time: '09:00 AM', pet: 'Bruno', patientId: 'VW-CL-000001-P01', client: 'Priya Sharma', clientId: 'VW-CL-000001', doctor: 'Dr. Anita Rao', reason: 'Vaccination', status: 'Confirmed', visitLocation: '12 MG Road, Bandra West, Mumbai — 400050' },
  { appointmentId: 'demo_a2', time: '10:30 AM', pet: 'Whiskers', patientId: 'VW-CL-000001-P02', client: 'Priya Sharma', clientId: 'VW-CL-000001', doctor: 'Dr. Anita Rao', reason: 'Skin infection', status: 'Confirmed', visitLocation: '12 MG Road, Bandra West, Mumbai — 400050' },
  { appointmentId: 'demo_a3', time: '12:00 PM', pet: 'Nandi', patientId: 'VW-CL-000002-P01', client: 'Ramesh Patel', clientId: 'VW-CL-000002', doctor: 'Dr. Vikram Sethi', reason: 'Routine check-up', status: 'Pending', visitLocation: '45 Ring Road, New Delhi — 110001' },
  { appointmentId: 'demo_a4', time: '03:30 PM', pet: 'Raja', patientId: 'VW-CL-000003-P01', client: 'Suresh Kumar', clientId: 'VW-CL-000003', doctor: 'Dr. Vikram Sethi', reason: 'Dental examination', status: 'Confirmed', visitLocation: '8 Brigade Road, Bengaluru — 560001' },
];

export const demoClinicalRecords = [
  { pet: 'Bruno', patientId: 'VW-CL-000001-P01', clientId: 'VW-CL-000001', species: 'Dog', breed: 'Labrador Retriever', date: '15 Sept 2026', reason: 'Vaccination', diagnosis: 'Healthy — routine vaccination administered', treatment: 'Rabies + DHPP booster', notes: 'No adverse reactions observed', followup: 'Annual check-up in 1 year' },
  { pet: 'Whiskers', patientId: 'VW-CL-000001-P02', clientId: 'VW-CL-000001', species: 'Cat', breed: 'Persian', date: '2 Sept 2026', reason: 'Skin Infection', diagnosis: 'Bacterial dermatitis — right flank', treatment: 'Antibacterial shampoo + oral antibiotics (7 days)', notes: 'Owner to monitor for hair loss', followup: 'Follow-up in 2 weeks' },
];

export const demoPrescriptions = [
  { rxId: 'demo_rx1', pet: 'Whiskers', patientId: 'VW-CL-000001-P02', clientId: 'VW-CL-000001', vet: 'Dr. Anita Rao', date: '2 Sept 2026', meds: 'Amoxicillin 250mg — 1 tablet twice daily for 7 days', status: 'Active' },
  { rxId: 'demo_rx2', pet: 'Bruno', patientId: 'VW-CL-000001-P01', clientId: 'VW-CL-000001', vet: 'Dr. Anita Rao', date: '15 Sept 2026', meds: 'Multivitamin supplement — 1 tablet daily', status: 'Completed' },
];

export const demoNotifications = [
  { id: 'demo_n1', title: 'Appointment Confirmed', message: 'Your home visit for Bruno on 15 Oct 2026 at 09:00 AM has been confirmed with Dr. Anita Rao.', type: 'appointment', entity_type: 'appointment', entity_id: 'demo_a1', is_read: false, created_at: '2026-10-13T10:00:00Z' },
  { id: 'demo_n2', title: 'Prescription Updated', message: 'Dr. Anita Rao updated the prescription for Whiskers. Please review the new dosage instructions.', type: 'prescription', entity_type: 'prescription', entity_id: 'demo_rx1', is_read: false, created_at: '2026-10-12T14:30:00Z' },
  { id: 'demo_n3', title: 'Payment Due', message: 'Your Gold Plan annual renewal of ₹12,000 is due on 1 Jan 2027. Set up auto-pay to avoid interruption.', type: 'payment', entity_type: 'subscription', entity_id: 'demo_sub1', is_read: true, created_at: '2026-10-10T09:00:00Z' },
  { id: 'demo_n4', title: 'Vaccination Reminder', message: 'Bruno is due for the annual Rabies + DHPP booster vaccination in 2 weeks. Book an appointment to stay on schedule.', type: 'system', entity_type: 'patient', entity_id: 'VW-CL-000001-P01', is_read: true, created_at: '2026-10-08T08:00:00Z' },
  { id: 'demo_n5', title: 'Follow-up Required', message: 'Whiskers needs a follow-up visit for the skin infection treated on 2 Sept 2026. Please book a follow-up appointment.', type: 'appointment', entity_type: 'clinical_record', entity_id: 'demo_cr2', is_read: true, created_at: '2026-10-05T11:00:00Z' },
];

export const demoDoctorNotifications = [
  { id: 'demo_dn1', title: 'New Appointment Assigned', message: 'You have been assigned a home visit for Bruno on 15 Oct 2026 at 09:00 AM. Please confirm or reject.', type: 'appointment', entity_type: 'appointment', entity_id: 'demo_a1', is_read: false, created_at: '2026-10-13T10:00:00Z' },
  { id: 'demo_dn2', title: 'Patient Record Updated', message: 'Clinical record for Whiskers has been updated with new dermatitis treatment notes.', type: 'system', entity_type: 'patient', entity_id: 'VW-CL-000001-P02', is_read: false, created_at: '2026-10-12T16:00:00Z' },
  { id: 'demo_dn3', title: 'Prescription Expiring', message: 'The Amoxicillin prescription for Whiskers expires in 2 days. Review and renew if needed.', type: 'prescription', entity_type: 'prescription', entity_id: 'demo_rx1', is_read: true, created_at: '2026-10-10T09:00:00Z' },
];

export const demoAdminNotifications = [
  { id: 'demo_an1', title: 'New Doctor Application', message: 'Dr. Meera Iyer has submitted a registration application. Review their credentials and approve or reject.', type: 'approval', entity_type: 'doctor', entity_id: 'demo_pd1', is_read: false, created_at: '2026-10-13T08:00:00Z' },
  { id: 'demo_an2', title: 'New Doctor Application', message: 'Dr. Rohan Gupta has submitted a registration application. Review their credentials and approve or reject.', type: 'approval', entity_type: 'doctor', entity_id: 'demo_pd2', is_read: false, created_at: '2026-10-12T08:00:00Z' },
  { id: 'demo_an3', title: 'Subscription Payment Received', message: 'Priya Sharma has paid ₹12,000 for the Gold Plan annual subscription.', type: 'payment', entity_type: 'subscription', entity_id: 'demo_sub1', is_read: true, created_at: '2026-10-01T09:00:00Z' },
];
