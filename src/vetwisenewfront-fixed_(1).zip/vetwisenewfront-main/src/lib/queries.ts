/**
 * VetWise API data access — wraps src/lib/api.ts.
 * Returns { data, error } for compatibility with existing call sites.
 */

import { api } from './api';

interface QueryResult<T> { data: T | null; error: string | null; }

async function wrap<T>(fn: () => Promise<T>): Promise<QueryResult<T>> {
  try { return { data: await fn(), error: null }; }
  catch (e) { return { data: null, error: e instanceof Error ? e.message : 'Request failed' }; }
}

// ---- Clients ----

export async function fetchClients() { return wrap(() => api.getClients()); }

export async function fetchClientById(clientId: string) {
  return wrap(async () => {
    const all = await api.getClients() as any[];
    return all?.find((c) => c.ownerId === clientId) ?? null;
  });
}

export async function fetchClientsByUser(userId: string) {
  return wrap(async () => {
    const all = await api.getClients() as any[];
    return all?.filter((c) => c.ownerId === userId || c.cognitoSub === userId) ?? [];
  });
}

// ---- Patients ----

export async function fetchPatients() { return wrap(() => api.getPatients()); }

export async function fetchPatientsByClient(ownerId: string) {
  return wrap(async () => {
    const all = await api.getPatients() as any[];
    return all?.filter((p) => p.ownerId === ownerId) ?? [];
  });
}

export async function fetchPatientById(patientId: string) {
  return wrap(async () => {
    const all = await api.getPatients() as any[];
    return all?.find((p) => p.petId === patientId) ?? null;
  });
}

// ---- Appointments ----

export async function fetchAppointments() { return wrap(() => api.getAppointments()); }

export async function fetchAppointmentsByClient(ownerId: string) {
  return wrap(async () => {
    const all = await api.getAppointments() as any[];
    return all?.filter((a) => a.ownerId === ownerId) ?? [];
  });
}

// ---- Clinical Records ----

export async function fetchClinicalRecords() { return wrap(() => api.getClinicalRecords()); }

export async function fetchClinicalRecordsByPatient(petId: string) {
  return wrap(() => api.getClinicalRecords(petId));
}

// ---- Prescriptions ----

export async function fetchPrescriptions() { return wrap(() => api.getPrescriptions()); }

export async function fetchPrescriptionsByClient(ownerId: string) {
  return wrap(async () => {
    const all = await api.getPrescriptions() as any[];
    return all?.filter((r) => r.ownerId === ownerId) ?? [];
  });
}

// ---- Payments ----

export async function fetchPayments() { return wrap(() => api.getPayments()); }

export async function fetchPaymentsByClient(ownerId: string) {
  return wrap(async () => {
    const all = await api.getPayments() as any[];
    return all?.filter((p) => p.ownerId === ownerId) ?? [];
  });
}

// ---- Subscriptions ----

export async function fetchSubscriptions() { return wrap(() => api.getSubscriptions()); }

export async function fetchSubscriptionPlans() {
  return wrap(async () => {
    const settings = await api.getSettings();
    return settings.plans;
  });
}

// ---- Doctors ----

export async function fetchDoctors() { return wrap(() => api.getDoctors()); }

export async function fetchPendingDoctors() { return wrap(() => api.getPendingDoctors()); }

export async function fetchDoctorByProfile(profileId: string) {
  return wrap(async () => {
    const all = await api.getDoctors() as any[];
    return all?.find((d) => d.cognitoSub === profileId) ?? null;
  });
}

// ---- Notifications ----

export async function fetchNotifications(_userId?: string) { return wrap(() => api.getNotifications()); }

export async function insertNotification(_body: Record<string, unknown>) { return null; }
export async function markNotificationRead(_id: string) { return null; }
export async function markAllNotificationsRead(_userId: string) { return null; }

// ---- Mutations ----

export async function insertClient(body: Record<string, unknown>) { return wrap(() => api.createClient(body)); }
export async function updateClient(clientId: string, body: Record<string, unknown>) { return wrap(() => api.updateClient(clientId, body)); }
export async function insertPatient(body: Record<string, unknown>) { return wrap(() => api.createPatient(body)); }
export async function updatePatient(patientId: string, body: Record<string, unknown>) { return wrap(() => api.updatePatient(patientId, body)); }
export async function insertAppointment(body: Record<string, unknown>) { return wrap(() => api.createAppointment(body)); }
export async function updateAppointment(id: string, body: Record<string, unknown>) { return wrap(() => api.updateAppointment(id, body)); }
export async function insertClinicalRecord(body: Record<string, unknown>) { return wrap(() => api.createClinicalRecord(body)); }
export async function insertPrescription(body: Record<string, unknown>) { return wrap(() => api.createPrescription(body)); }
export async function approveDoctor(doctorId: string, _adminId: string) { return wrap(() => api.approveDoctor(doctorId)); }
export async function rejectDoctor(doctorId: string, _reason: string) { return wrap(() => api.rejectDoctor(doctorId)); }
export async function insertDoctor(body: Record<string, unknown>) { return wrap(() => api.createDoctor(body)); }

// ---- Prescriptions PDF ----

export async function fetchPrescriptionPdf(id: string) { return wrap(() => api.getPrescriptionPdf(id)); }
export async function finalizePrescription(id: string) { return wrap(() => api.finalizePrescription(id)); }

// ---- Serviceability ----

export async function checkServiceability(lat: number, lng: number) {
  return wrap(() => api.checkServiceability(lat, lng));
}

// ---- Settings ----

export async function fetchSettings() { return wrap(() => api.getSettings()); }

// ---- Payments: order + verify ----

export async function createPaymentOrder(resourceType: string, resourceId: string) {
  return wrap(() => api.createOrder({ resourceType, resourceId }));
}

export async function verifyPayment(body: { razorpayOrderId: string; razorpayPaymentId: string; razorpaySignature: string; paymentId: string }) {
  return wrap(() => api.verifyPayment(body));
}
