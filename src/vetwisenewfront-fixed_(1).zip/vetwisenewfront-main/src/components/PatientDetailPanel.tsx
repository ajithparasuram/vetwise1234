/**
 * PatientDetailPanel — full patient profile for doctors and admins.
 *
 * Shows: Patient ID, name, species, breed, sex, age, weight, photos,
 * owner/client info, Client ID, medical info, breeding, clinical records,
 * prescriptions, appointments, follow-ups.
 */

import { useState } from 'react';
import {
  PawPrint, X, MapPin, Phone, CalendarDays, FileText, Heart,
  ClipboardList, Clock3, ImageIcon, Syringe, AlertCircle,
} from 'lucide-react';
import { BreedingPanel } from './BreedingPanel';
import { demoPatients, demoClients, demoClinicalRecords, demoPrescriptions, demoAppointments } from '@/lib/demo-data';

interface PatientDetailPanelProps {
  patientId: string;
  role: 'doctor' | 'admin';
  onClose: () => void;
}

export function PatientDetailPanel({ patientId, role, onClose }: PatientDetailPanelProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'medical' | 'breeding' | 'records' | 'prescriptions' | 'appointments'>('overview');

  // Find patient in demo data
  const demoPatient = demoPatients.find((p) => p[6] === patientId);
  const client = demoClients.find((c) => c.clientId === (demoPatient?.[6] as string ?? ''));

  if (!demoPatient) {
    return (
      <div className="patient-detail-panel">
        <div className="detail-head">
          <div className="empty-state"><PawPrint size={36} /><h3>Patient not found</h3><p>This patient may not exist or you may not have access.</p></div>
          <button className="icon-btn" onClick={onClose}><X size={18} /></button>
        </div>
      </div>
    );
  }

  const name = demoPatient[0] as string;
  const species = demoPatient[1] as string;
  const breedInfo = demoPatient[2] as string;
  const ageWeight = demoPatient[3] as string;
  const ownerName = demoPatient[4] as string;
  const visits = demoPatient[5] as string;
  const pid = demoPatient[6] as string;

  const clinicalRecords = demoClinicalRecords.filter((r) => r.patientId === patientId);
  const rxRecords = demoPrescriptions.filter((r) => r.patientId === patientId);
  const apptRecords = demoAppointments.filter((a) => a.patientId === patientId);

  const tabs = [
    { key: 'overview' as const, label: 'Overview', icon: PawPrint },
    { key: 'medical' as const, label: 'Medical', icon: Heart },
    { key: 'breeding' as const, label: 'Breeding', icon: Heart },
    { key: 'records' as const, label: 'Records', icon: FileText },
    { key: 'prescriptions' as const, label: 'Rx', icon: ClipboardList },
    { key: 'appointments' as const, label: 'Visits', icon: CalendarDays },
  ];

  return (
    <div className="patient-detail-panel">
      <div className="detail-head">
        <div className="pet-icon large"><PawPrint size={24} /></div>
        <div className="detail-title">
          <h2>{name}</h2>
          <p>
            <span className="pid-badge">{pid}</span>
            <em className={`tag ${species.toLowerCase()}`}>{species}</em>
            <span className="muted">{breedInfo}</span>
          </p>
          <p className="owner-line">
            <small>Owner: <strong>{ownerName}</strong></small>
            {client && <small className="cid-badge">{client.clientId}</small>}
          </p>
        </div>
        <button className="icon-btn" onClick={onClose}><X size={18} /></button>
      </div>

      <div className="patient-tabs">
        {tabs.map((t) => (
          <button
            key={t.key}
            className={activeTab === t.key ? 'active' : ''}
            onClick={() => setActiveTab(t.key)}
          >
            <t.icon size={14} /> {t.label}
          </button>
        ))}
      </div>

      <div className="patient-detail-body">
        {activeTab === 'overview' && (
          <div className="overview-tab">
            <div className="info-grid">
              <div><label>PATIENT ID</label><strong className="pid-text">{pid}</strong></div>
              <div><label>SPECIES</label><strong>{species}</strong></div>
              <div><label>BREED</label><strong>{breedInfo.split(' · ')[0]}</strong></div>
              <div><label>SEX</label><strong>{species === 'Dog' ? 'Male' : 'Female'}</strong></div>
              <div><label>AGE</label><strong>{ageWeight.split(' · ')[0]}</strong></div>
              <div><label>WEIGHT</label><strong>{ageWeight.split(' · ')[1] ?? 'Not recorded'}</strong></div>
              <div><label>VISITS</label><strong>{visits}</strong></div>
              <div><label>STATUS</label><strong>Active</strong></div>
            </div>

            {client && (
              <div className="owner-section">
                <h4>Owner / Client</h4>
                <div className="info-grid">
                  <div><label>CLIENT ID</label><strong className="cid-text">{client.clientId}</strong></div>
                  <div><label>NAME</label><strong>{client.name}</strong></div>
                  <div><label>PHONE</label><strong>{client.phone}</strong></div>
                  <div><label>EMAIL</label><strong>{client.email}</strong></div>
                  <div className="wide"><label>ADDRESS</label><strong>{client.address}</strong></div>
                </div>
              </div>
            )}

            <div className="photos-section">
              <h4>Photos & Media</h4>
              <div className="photo-placeholder-row">
                <div className="photo-placeholder"><ImageIcon size={24} /><small>Face Photo</small></div>
                <div className="photo-placeholder"><ImageIcon size={24} /><small>Body Photo</small></div>
                <div className="photo-placeholder"><ImageIcon size={24} /><small>Additional</small></div>
              </div>
              <p className="photo-hint">No photos uploaded yet. Photos will appear here when the client uploads them.</p>
            </div>
          </div>
        )}

        {activeTab === 'medical' && (
          <div className="medical-tab">
            <div className="info-grid">
              <div className="wide"><label><AlertCircle size={12} /> ALLERGIES</label><strong>None known</strong></div>
              <div className="wide"><label>EXISTING CONDITIONS</label><strong>None</strong></div>
              <div className="wide"><label><Syringe size={12} /> VACCINATIONS</label><strong>Rabies (Jan 2026), DHPP (Jan 2026)</strong></div>
              <div className="wide"><label>CURRENT MEDICATIONS</label><strong>Multivitamin supplement</strong></div>
              <div className="wide"><label>MEDICAL HISTORY</label><strong>Routine vaccinations up to date</strong></div>
              <div className="wide"><label>SPECIAL REQUIREMENTS</label><strong>Sensitive stomach — avoid dairy</strong></div>
            </div>
          </div>
        )}

        {activeTab === 'breeding' && (
          <BreedingPanel
            patientId={pid}
            patientName={name}
            species={species}
            breedingEligible={species !== 'Cat' && species !== 'Rabbit'}
            role={role}
          />
        )}

        {activeTab === 'records' && (
          <div className="records-tab">
            {clinicalRecords.length === 0 ? (
              <p className="empty-hint">No clinical records found for this patient.</p>
            ) : (
              clinicalRecords.map((r) => (
                <div className="record-card" key={r.date}>
                  <div className="record-pet">
                    <div className="pet-icon"><FileText size={16} /></div>
                    <div><strong>{r.reason}</strong><small>{r.date}</small></div>
                  </div>
                  <div className="record-grid">
                    <div><label>DIAGNOSIS</label><strong>{r.diagnosis}</strong></div>
                    <div><label>TREATMENT</label><strong>{r.treatment}</strong></div>
                    <div><label>NOTES</label><strong>{r.notes}</strong></div>
                    <div><label>FOLLOW-UP</label><strong>{r.followup}</strong></div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'prescriptions' && (
          <div className="rx-tab">
            {rxRecords.length === 0 ? (
              <p className="empty-hint">No prescriptions for this patient.</p>
            ) : (
              rxRecords.map((r) => (
                <div className="rx-card" key={r.rxId}>
                  <div className="pet-icon"><ClipboardList size={16} /></div>
                  <div>
                    <strong>{r.vet} <small>· {r.date}</small></strong>
                    <div className="rx-meds">{r.meds}</div>
                    <small>Status: <em className={`status ${r.status === 'Active' ? 'confirmed' : 'pending'}`}>{r.status.toUpperCase()}</em></small>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'appointments' && (
          <div className="appt-tab">
            {apptRecords.length === 0 ? (
              <p className="empty-hint">No appointments for this patient.</p>
            ) : (
              apptRecords.map((a) => (
                <div className="appointment-card" key={a.appointmentId}>
                  <div className="time">{a.time}</div>
                  <div><strong>{a.reason}</strong><small>{a.doctor}</small></div>
                  <span className={`status ${a.status.toLowerCase()}`}>{a.status.toUpperCase()}</span>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
