/**
 * PatientSearch — powerful backend-driven search for doctors and admins.
 *
 * Searches by: Patient ID, Client ID, animal name, breed, species, client name, phone.
 * Results show: Patient ID, animal name, species, breed, Client ID, client name, address, phone, status, last visit.
 * Clicking a result opens the patient profile.
 * Privacy is enforced by role — doctor sees only authorized records, admin sees all.
 */

import { useState, useMemo } from 'react';
import { Search, X, PawPrint, MapPin, Phone, ArrowUpRight, Loader2, AlertTriangle, RotateCw } from 'lucide-react';
import { SPECIES_LIST } from '@/lib/demo-data';
import { fetchPatients, fetchClients } from '@/lib/queries';
import { demoPatients, demoClients } from '@/lib/demo-data';

interface SearchResult {
  patientId: string;
  name: string;
  species: string;
  customSpecies: string | null;
  breed: string | null;
  sex: string | null;
  clientId: string;
  clientName: string;
  city: string;
  state: string;
  phone: string;
  status: string;
  lastVisit: string;
}

interface PatientSearchProps {
  role: 'doctor' | 'admin';
  onSelectPatient: (patientId: string) => void;
  demoMode?: boolean;
}

export function PatientSearch({ role, onSelectPatient, demoMode = false }: PatientSearchProps) {
  const [query, setQuery] = useState('');
  const [speciesFilter, setSpeciesFilter] = useState('');
  const [results, setResults] = useState<SearchResult[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [clientsUnavailable, setClientsUnavailable] = useState(false);

  const buildDemoResults = (): SearchResult[] => {
    return demoPatients.map((p) => {
      const client = demoClients.find((c) => c.clientId === p[6]);
      return {
        patientId: p[6] as string,
        name: p[0] as string,
        species: p[1] as string,
        customSpecies: null,
        breed: (p[2] as string).split(' · ')[0],
        sex: null,
        clientId: p[6] as string,
        clientName: p[4] as string,
        city: client?.city ?? '',
        state: '',
        phone: client?.phone ?? '',
        status: client?.status ?? 'Active',
        lastVisit: p[5] as string,
      };
    });
  };

  const performSearch = async () => {
    if (loading) return;
    setLoading(true);
    setSearched(true);
    setError(null);
    setClientsUnavailable(false);

    let list: SearchResult[];
    if (demoMode) {
      // Demo workspace only: fixtures are used because the user explicitly chose demo mode.
      list = buildDemoResults();
    } else {
      const [patRes, cliRes] = await Promise.all([fetchPatients(), fetchClients()]);
      if (patRes.error || !patRes.data) {
        // A failed request is not an empty result and never falls back to demo records.
        setError(patRes.error ?? 'The server did not return patient records.');
        setResults(null);
        setLoading(false);
        return;
      }
      if (cliRes.error) setClientsUnavailable(true);
      const clients = (cliRes.data ?? []) as any[];
      list = (patRes.data as any[]).map((p) => {
        const c = clients.find((cl) => cl.ownerId === p.ownerId);
        return {
          patientId: p.petId ?? '',
          name: p.name ?? '',
          species: p.species ?? '',
          customSpecies: p.customSpecies ?? null,
          breed: p.breed ?? null,
          sex: p.sex ?? null,
          clientId: p.ownerId ?? '',
          clientName: c?.name ?? '',
          city: c?.city ?? '',
          state: c?.state ?? '',
          phone: c?.phone ?? '',
          status: c?.status ?? p.status ?? 'Active',
          lastVisit: p.lastVisit ?? 'No visits yet',
        } as SearchResult;
      });
    }

    const q = query.trim().toLowerCase();
    if (q) {
      list = list.filter((r) =>
        r.patientId.toLowerCase().includes(q) ||
        r.name.toLowerCase().includes(q) ||
        (r.breed ?? '').toLowerCase().includes(q) ||
        r.species.toLowerCase().includes(q) ||
        r.clientId.toLowerCase().includes(q) ||
        r.clientName.toLowerCase().includes(q) ||
        r.phone.toLowerCase().includes(q),
      );
    }
    if (speciesFilter) list = list.filter((r) => r.species === speciesFilter);

    // A successful response with zero matches is a genuine empty result.
    setResults(list);
    setLoading(false);
  };

  const filteredResults = useMemo(() => {
    if (!results) return [];
    if (!speciesFilter) return results;
    return results.filter((r) => r.species === speciesFilter);
  }, [results, speciesFilter]);

  return (
    <div className="patient-search-container">
      <div className="search-bar-row">
        <div className="searchbar large">
          <Search size={18} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && performSearch()}
            placeholder="Search by Patient ID, Client ID, animal name, breed, species, client name, or phone..."
          />
          {query && <button onClick={() => { setQuery(''); setResults(null); setSearched(false); }}><X size={15} /></button>}
        </div>
        <select className="species-filter" value={speciesFilter} onChange={(e) => setSpeciesFilter(e.target.value)}>
          <option value="">All Species</option>
          {SPECIES_LIST.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <button className="primary" onClick={performSearch} disabled={loading}>
          {loading ? <Loader2 size={16} className="spin" /> : <Search size={16} />}
          Search
        </button>
      </div>

      <div className="search-meta">
        <small>
          {role === 'doctor'
            ? 'You will only see patients you are authorized to access.'
            : 'Admin access: all patient records are visible.'}
        </small>
        {demoMode && <small style={{ color: '#e8870a', display: 'block' }}>DEMO — NOT SAVED TO SERVER. These are sample records.</small>}
        {clientsUnavailable && <small style={{ color: '#e8870a', display: 'block' }}>Owner details could not be loaded, so owner names and phones may be blank.</small>}
      </div>

      {searched && (
        <div className="search-results">
          {loading ? (
            <div className="search-loading"><Loader2 size={24} className="spin" /><p>Searching...</p></div>
          ) : error ? (
            <div className="empty-state"><AlertTriangle size={32} /><h3>Search failed</h3><p>{error}</p><button className="primary" onClick={performSearch}><RotateCw size={16} /> Retry</button></div>
          ) : filteredResults.length === 0 ? (
            <div className="empty-state"><PawPrint size={36} /><h3>No results found</h3><p>Try a different search term or filter.</p></div>
          ) : (
            <>
              <div className="results-count">{filteredResults.length} {filteredResults.length === 1 ? 'result' : 'results'} found</div>
              {filteredResults.map((r) => (
                <button
                  key={r.patientId}
                  className="search-result-card"
                  onClick={() => onSelectPatient(r.patientId)}
                >
                  <div className="result-pet-icon"><PawPrint size={18} /></div>
                  <div className="result-main">
                    <div className="result-primary">
                      <strong>{r.name}</strong>
                      <em className={`tag ${r.species.toLowerCase()}`}>{r.species === 'Other' ? r.customSpecies ?? 'Other' : r.species}</em>
                      {r.breed && <span className="muted">{r.breed}</span>}
                    </div>
                    <div className="result-ids">
                      <span className="pid">{r.patientId}</span>
                      <span className="dot">·</span>
                      <span className="cid">{r.clientId}</span>
                    </div>
                    <div className="result-secondary">
                      <span>{r.clientName}</span>
                      <small><MapPin size={11} /> {r.city}{r.state ? `, ${r.state}` : ''}</small>
                      <small><Phone size={11} /> {r.phone}</small>
                    </div>
                  </div>
                  <div className="result-actions">
                    <span className={`status ${r.status.toLowerCase()}`}>{r.status.toUpperCase()}</span>
                    <small>Last: {r.lastVisit}</small>
                    <span className="open-link">Open Profile <ArrowUpRight size={12} /></span>
                  </div>
                </button>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  );
}
